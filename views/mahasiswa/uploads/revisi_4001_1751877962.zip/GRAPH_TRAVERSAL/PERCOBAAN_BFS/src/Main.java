public class Main {
    public static void main(String[] args) {
        Graph myGraph = new Graph();

        Vertex a = new Vertex("A");
        Vertex b = new Vertex("B");
        Vertex c = new Vertex("C");
        Vertex d = new Vertex("D");
        Vertex e = new Vertex("E");

        myGraph.addVertex(a);
        myGraph.addVertex(b);
        myGraph.addVertex(c);
        myGraph.addVertex(d);
        myGraph.addVertex(e);

        myGraph.addEdge(a, b);
        myGraph.addEdge(b, c);
        myGraph.addEdge(b, d);
        myGraph.addEdge(c, e);

        System.out.println("--- Adjacency Matrix ---");
        myGraph.displayAdjacent();

        System.out.println("\n--- Incidence Matrix ---");
        myGraph.displayIncidence();

        System.out.println("");
        myGraph.BFS(c);
    }
}