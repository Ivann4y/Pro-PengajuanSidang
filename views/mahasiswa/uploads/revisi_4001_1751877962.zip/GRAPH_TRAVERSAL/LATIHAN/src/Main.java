public class Main {
    public static void main(String[] args) {
        Graph myGraph = new Graph();

        Vertex a = new Vertex("A");
        Vertex b = new Vertex("B");
        Vertex c = new Vertex("C");
        Vertex d = new Vertex("D");
        Vertex e = new Vertex("E");

        myGraph.addVertex(a);
        myGraph.addVertex(b);
        myGraph.addVertex(c);
        myGraph.addVertex(d);
        myGraph.addVertex(e);

        myGraph.addEdge(a, b, 50.0);
        myGraph.addEdge(a, c, 100.0);
        myGraph.addEdge(b, d, 93.0);
        myGraph.addEdge(c, d, 112.0);
        myGraph.addEdge(d, e, 87.0);
        myGraph.addEdge(c, e, 210.0);


        System.out.println("--- Adjacency Matrix ---");
        myGraph.displayAdjacent();

        System.out.println("\n--- Incidence Matrix ---");
        myGraph.displayIncidence();

        System.out.println("\n--- BFS starting from Vertex A ---");
        myGraph.BFS(a);

        System.out.println("\n--- DFS starting from Vertex A ---");
        myGraph.DFS(a);

        myGraph.findShortestPath(a, e);
    }
}