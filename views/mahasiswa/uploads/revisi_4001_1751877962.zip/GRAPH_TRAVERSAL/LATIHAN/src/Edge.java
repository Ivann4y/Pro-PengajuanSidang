class Edge {
    private String label;
    private Vertex fromVertex;
    private Vertex toVertex;
    private Double weight;

    public Edge(String label, Vertex fromVertex, Vertex toVertex) {
        this(label, fromVertex, toVertex, 0.0);
    }

    public Edge(String label, Vertex fromVertex, Vertex toVertex, Double weight) {
        this.label = label;
        this.fromVertex = fromVertex;
        this.toVertex = toVertex;
        this.weight = weight;
    }

    public Double getWeight() {
        return weight;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public void setWeight(Double weight) {
        this.weight = weight;
    }

    public Vertex getFromVertex() {
        return fromVertex;
    }

    public void setFromVertex(Vertex fromVertex) {
        this.fromVertex = fromVertex;
    }

    public Vertex getToVertex() {
        return toVertex;
    }

    public void setToVertex(Vertex toVertex) {
        this.toVertex = toVertex;
    }

    @Override
    public String toString() {
        return "Edge{" +
                "label='" + label + '\'' +
                ", fromVertex=" + fromVertex.getLabel() +
                ", toVertex=" + toVertex.getLabel() +
                ", weight=" + weight +
                '}';
    }
}