import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Stack;

class Graph {

    private ArrayList<Vertex> vertices;
    private ArrayList<Edge> edges;

    public Graph() {
        this.vertices = new ArrayList<>();
        this.edges = new ArrayList<>();
    }

    private boolean isVertexExist(Vertex vertex) {
        return vertices.contains(vertex);
    }

    private int getVertexIndex(Vertex vertex) {
        return vertices.indexOf(vertex);
    }

    public void addVertex(Vertex vertex) {
        if (isVertexExist(vertex)) {
            System.out.println("Vertex '" + vertex.getLabel() + "' Already Exist");
            return;
        }
        vertices.add(vertex);
        System.out.println("Added vertex: " + vertex.getLabel());
    }

    public void addEdge(Vertex fromVertex, Vertex toVertex, Double weight) {
        if (!isVertexExist(fromVertex)) {
            System.out.println("Error: 'From Vertex' (" + fromVertex.getLabel() + ") does not exist.");
            return;
        }
        if (!isVertexExist(toVertex)) {
            System.out.println("Error: 'To Vertex' (" + toVertex.getLabel() + ") does not exist.");
            return;
        }

        boolean edgeExists = false;
        for (Edge edge : edges) {
            if ((Objects.equals(edge.getFromVertex().getLabel(), fromVertex.getLabel()) && Objects.equals(edge.getToVertex().getLabel(), toVertex.getLabel())) ||
                    (Objects.equals(edge.getFromVertex().getLabel(), toVertex.getLabel()) && Objects.equals(edge.getToVertex().getLabel(), fromVertex.getLabel()))) {
                System.out.println("Edge between " + fromVertex.getLabel() + " and " + toVertex.getLabel() + " already exists.");
                edgeExists = true;
                break;
            }
        }

        if (!edgeExists) {
            edges.add(new Edge("e" + edges.size(), fromVertex, toVertex, weight));
            edges.add(new Edge("e" + edges.size(), toVertex, fromVertex, weight));
            System.out.println("Added edge: " + fromVertex.getLabel() + " <-> " + toVertex.getLabel() + " (Weight: " + weight + ")");
        }
    }

    public void addEdge(Vertex fromVertex, Vertex toVertex) {
        addEdge(fromVertex, toVertex, 0.0);
    }


    public void displayAdjacent() {
        if (vertices.isEmpty()) {
            System.out.println("Graph is empty. Cannot display adjacency matrix.");
            return;
        }

        int numV = vertices.size();
        int[][] adjMatrix = new int[numV][numV];

        for (Edge edge : edges) {
            int fromIndex = getVertexIndex(edge.getFromVertex());
            int toIndex = getVertexIndex(edge.getToVertex());

            if (fromIndex != -1 && toIndex != -1) {
                adjMatrix[fromIndex][toIndex] = 1;
            }
        }

        System.out.print("       ");
        for (Vertex v : vertices) {
            System.out.printf("%-5s", v.getLabel());
        }
        System.out.println();

        for (int i = 0; i < numV; i++) {
            System.out.printf("%-5s", vertices.get(i).getLabel());
            for (int j = 0; j < numV; j++) {
                System.out.printf("%-5d", adjMatrix[i][j]);
            }
            System.out.println();
        }
    }

    public void displayIncidence() {
        if (vertices.isEmpty() || edges.isEmpty()) {
            System.out.println("Graph is empty or has no edges. Cannot display incidence matrix.");
            return;
        }

        int numV = vertices.size();
        int numE = edges.size();
        int[][] incMatrix = new int[numV][numE];

        System.out.print("       ");
        for (Edge edge : edges) {
            System.out.printf("%-5s", edge.getLabel());
        }
        System.out.println();

        for (int i = 0; i < numV; i++) {
            System.out.printf("%-5s", vertices.get(i).getLabel());
            for (int j = 0; j < numE; j++) {
                Vertex currentVertex = vertices.get(i);
                Edge currentEdge = edges.get(j);

                if (Objects.equals(currentVertex.getLabel(), currentEdge.getFromVertex().getLabel())) {
                    incMatrix[i][j] = 1;
                } else if (Objects.equals(currentVertex.getLabel(), currentEdge.getToVertex().getLabel())) {
                    incMatrix[i][j] = -1;
                } else {
                    incMatrix[i][j] = 0;
                }
                System.out.printf("%-5d", incMatrix[i][j]);
            }
            System.out.println();
        }
    }

    public void printGraph() {
        System.out.println("Vertices in the graph:");
        for (Vertex vertex : vertices) {
            System.out.println("- " + vertex.getLabel());
        }

        System.out.println("\nEdges in the graph:");
        for (Edge edge : edges) {
            System.out.println("- " + edge.getFromVertex().getLabel() + " -> " + edge.getToVertex().getLabel() + " (Weight: " + edge.getWeight() + ")");
        }
    }

    public void BFS(Vertex startVertex) {
        if (!isVertexExist(startVertex)) {
            System.out.println("Error: Start vertex '" + startVertex.getLabel() + "' does not exist in the graph.");
            return;
        }

        for (Vertex v : vertices) {
            v.setWasVisited(false);
        }

        Queue<Vertex> queue = new LinkedList<>();

        queue.offer(startVertex);
        startVertex.setWasVisited(true);

        System.out.println("\n--- Breadth-First Search (BFS) starting from " + startVertex.getLabel() + " (Undirected Traversal) ---");
        while (!queue.isEmpty()) {
            Vertex currentVertex = queue.poll();
            System.out.print(currentVertex.getLabel() + " ");

            for (Edge edge : edges) {
                if (Objects.equals(edge.getFromVertex().getLabel(), currentVertex.getLabel())) {
                    Vertex neighbor = edge.getToVertex();
                    if (!neighbor.isWasVisited()) {
                        neighbor.setWasVisited(true);
                        queue.offer(neighbor);
                    }
                }
            }
        }
        System.out.println("\n--- BFS Complete ---");
    }

    public void DFS(Vertex startVertex) {
        if (!isVertexExist(startVertex)) {
            System.out.println("Error: Start vertex '" + startVertex.getLabel() + "' does not exist in the graph.");
            return;
        }

        for (Vertex v : vertices) {
            v.setWasVisited(false);
        }

        Stack<Vertex> stack = new Stack<>();

        stack.push(startVertex);
        startVertex.setWasVisited(true);

        System.out.println("\n--- Depth-First Search (DFS) starting from " + startVertex.getLabel() + " (Undirected Traversal) ---");
        while (!stack.isEmpty()) {
            Vertex currentVertex = stack.pop();
            System.out.print(currentVertex.getLabel() + " ");

            ArrayList<Vertex> neighbors = new ArrayList<>();
            for (Edge edge : edges) {
                if (Objects.equals(edge.getFromVertex().getLabel(), currentVertex.getLabel())) {
                    Vertex neighbor = edge.getToVertex();
                    if (!neighbor.isWasVisited()) {
                        neighbors.add(neighbor);
                    }
                }
            }

            for (int i = neighbors.size() - 1; i >= 0; i--) {
                Vertex neighbor = neighbors.get(i);
                if (!neighbor.isWasVisited()) {
                    neighbor.setWasVisited(true);
                    stack.push(neighbor);
                }
            }
        }
        System.out.println("\n--- DFS Complete ---");
    }

    public void findShortestPath(Vertex source, Vertex destination) {
        if (!isVertexExist(source)) {
            System.out.println("Error: Source vertex '" + source.getLabel() + "' does not exist.");
            return;
        }
        if (!isVertexExist(destination)) {
            System.out.println("Error: Destination vertex '" + destination.getLabel() + "' does not exist.");
            return;
        }

        Map<Vertex, Double> distances = new HashMap<>();
        Map<Vertex, Vertex> predecessors = new HashMap<>();
        PriorityQueue<PathNode> pq = new PriorityQueue<>();

        for (Vertex v : vertices) {
            distances.put(v, Double.POSITIVE_INFINITY);
            predecessors.put(v, null);
        }
        distances.put(source, 0.0);

        pq.add(new PathNode(source, 0.0));

        System.out.println("\n--- Finding Shortest Path from " + source.getLabel() + " to " + destination.getLabel() + " using Dijkstra ---");

        while (!pq.isEmpty()) {
            PathNode currentPathNode = pq.poll();
            Vertex currentVertex = currentPathNode.vertex;
            double currentDistance = currentPathNode.distance;

            if (currentDistance > distances.get(currentVertex)) {
                continue;
            }

            if (Objects.equals(currentVertex.getLabel(), destination.getLabel())) {
                break;
            }

            for (Edge edge : edges) {
                if (Objects.equals(edge.getFromVertex().getLabel(), currentVertex.getLabel())) {
                    Vertex neighbor = edge.getToVertex();
                    double edgeWeight = edge.getWeight();
                    double newDistance = currentDistance + edgeWeight;

                    if (newDistance < distances.get(neighbor)) {
                        distances.put(neighbor, newDistance);
                        predecessors.put(neighbor, currentVertex);
                        pq.add(new PathNode(neighbor, newDistance));
                    }
                }
            }
        }

        List<Vertex> path = new LinkedList<>();
        double totalDistance = distances.get(destination);

        if (totalDistance == Double.POSITIVE_INFINITY) {
            System.out.println("No path found from " + source.getLabel() + " to " + destination.getLabel() + ".");
        } else {
            Vertex step = destination;
            while (step != null) {
                path.add(step);
                step = predecessors.get(step);
            }
            Collections.reverse(path);

            System.out.print("Shortest path from " + source.getLabel() + " to " + destination.getLabel() + ": ");
            for (int i = 0; i < path.size(); i++) {
                System.out.print(path.get(i).getLabel());
                if (i < path.size() - 1) {
                    System.out.print(" -> ");
                }
            }
            System.out.println("\nTotal distance: " + totalDistance);
        }
        System.out.println("--- Dijkstra Complete ---");
    }
}