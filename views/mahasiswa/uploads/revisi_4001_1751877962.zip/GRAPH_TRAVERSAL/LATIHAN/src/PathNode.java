import java.util.Objects;

public class PathNode implements Comparable<PathNode> {
    Vertex vertex;
    double distance;

    public PathNode(Vertex vertex, double distance) {
        this.vertex = vertex;
        this.distance = distance;
    }

    @Override
    public int compareTo(PathNode other) {
        return Double.compare(this.distance, other.distance);
    }
}