public class LinkedList {
    private Node head;
    private Node tail;
    private int size;
    private final int pageLimit = 2;
    public int page;

    public void addProduct(DataMotor produk) {
        Node node = new Node(produk);
        if (head == null) {
            head = tail = node;
        } else {
            tail.setNext(node);
            node.setPrev(tail);
            tail = node;
        }
        size++;
    }

    public void display() {
        if (head == null) {
            System.out.println("\nData kosong.");
            return;
        }

        Node current = head;
        int start = page * pageLimit;
        int end = Math.min(start + pageLimit, size);

        // Skip ke node awal halaman
        for (int i = 0; i < start; i++) {
            if (current != null) current = current.getNext();
        }

        System.out.printf("\n%-15s %-20s %15s\n", "Jenis", "Nama", "Harga");
        System.out.println("-----------------------------------------------------------");

        for (int i = start; i < end && current != null; i++) {
            System.out.println(current.getDataMotor());
            current = current.getNext();
        }
    }

    public void nextPage() {
        if (page < getTotalPages() - 1) {
            page++;
        }
    }

    public void prevPage() {
        if (page > 0) {
            page--;
        }
    }

    public int getPage() {
        return page;
    }

    public int getTotalPages() {
        return (int) Math.ceil((double) size / pageLimit);
    }
}
