import java.util.Scanner;

public class Main {
    private static Scanner sc = new Scanner(System.in);
    public static LinkedList list = new LinkedList();

    public static void main(String[] args) {
        char select;
        do {
            list.display();
            System.out.println("Page: " + (list.getPage() + 1) + "/" + list.getTotalPages());
            System.out.println("[p] Previous\t\t[n] Next\t\t[a] Add\t\t[q] Quit");
            System.out.print("Choice: ");
            select = sc.next().charAt(0);

            switch (select) {
                case 'n':
                    list.nextPage();
                    break;
                case 'p':
                    list.prevPage();
                    break;
                case 'a':
                    addMotor();
                    break;
            }
        } while (select != 'q');
    }

    public static void addMotor() {
        System.out.println("Tambah Motor");
        System.out.print("Jenis: ");
        String jenis = sc.next();
        System.out.print("Nama: ");
        String nama = sc.next();
        System.out.print("Harga: ");
        double harga = sc.nextDouble();

        list.addProduct(new DataMotor(jenis, nama, harga));
    }
}