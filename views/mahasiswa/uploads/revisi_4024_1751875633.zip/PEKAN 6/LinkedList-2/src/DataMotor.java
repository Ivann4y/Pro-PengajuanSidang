public class DataMotor {
    private String jenis;
    private String nama;
    private Double harga;

    public DataMotor(String jenis, String nama, Double harga) {
        this.jenis = jenis;
        this.nama = nama;
        this.harga = harga;
    }

    public DataMotor() {
    }

    public String getJenis() {
        return jenis;
    }
    public String getNama() {
        return nama;
    }
    public Double getHarga() {
        return harga;
    }

    @Override
    public String toString() {
        return String.format("%-15s %-20s %15.2f", jenis, nama, harga);
    }
}
