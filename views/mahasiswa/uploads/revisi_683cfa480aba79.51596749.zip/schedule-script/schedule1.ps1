$waktu = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
Write-output "aku dijalankan schedulr pada $waktu" >> c:\schedule-script\schedule.log