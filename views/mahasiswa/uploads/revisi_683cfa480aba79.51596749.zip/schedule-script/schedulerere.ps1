$timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
$logFile = 'C:\schedule-script\schedule111.log'
if (!(Test-Path $logFile)) {
    New-Item -Path $logFile -ItemType File -Force
}

"$timestamp - Script executed at 11:52 PM" | Out-File -FilePath $logFile -Append -Encoding utf8