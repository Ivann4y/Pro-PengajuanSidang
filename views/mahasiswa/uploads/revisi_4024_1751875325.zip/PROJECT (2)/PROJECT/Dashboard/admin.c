#include "../heading.h"
#include "../desain.h"
#include "../Master/Karyawan/karyawan.h"
#include "../Master/Barang/Barang.h"
#include "../Master/JasaFoto/jasa.h"
#include "../Master/Membership/Membership.h"

void menuAwal() {
    int pilih = 0;
    char *menus[] = {"Kelola Karyawan", "Kelola Barang", "Kelola Jasa", "Kelola Member", "Keluar"};
    char key;
    int menuSize = sizeof(menus) / sizeof(menus[0]);

    while (1) {
        desainAdmin();
        gotoxy(1, 8);
        printf("Pilih Menu: ");
        y = 9;
        for (i = 0; i < menuSize; i++) {
            gotoxy(1, y+1);
            if (i == pilih) {
                printf(" ==> %s", menus[i]);
            } else {
                printf("    %s", menus[i]);
            }
            y++;
        }

        key = getch();
        if (key == 72 && pilih > 0) {
            pilih--;
        } else if (key == 80 && pilih < menuSize - 1) {
            pilih++;
        } else if (key == 13) {
            switch (i)
            {
            case 0:
                karyawan();
                break;
            case 1:
                barang();
                break;
            case 2:
                jasa();
                break;
            case 3:
                member();
                break;
            default:
                break;
            }
            break;
        }

        // Clear the screen without using system("cls")
        for (int k = 8; k <= y; k++) {
            gotoxy(1, k);
            printf("                              ");
        }
        gotoxy(1, 8);
    }
}

int main() {
    menuAwal();
    return 0;
}