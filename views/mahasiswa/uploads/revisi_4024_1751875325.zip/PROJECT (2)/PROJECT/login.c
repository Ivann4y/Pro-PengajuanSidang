#include "heading.h"
#include "desain.h"

int desain() {
    setFullscreen();
    desainLogin();
    getchar();
}

int main() {
    FILE *karyawan;
    dataKaryawan kData;
    karyawan = fopen("Master/Karyawan/DataKaryawan.dat", "rb");

    if (karyawan == NULL) {
        printf("File tidak dapat dibuka");
        return 1;
    } else {
        gotoxy(10, 15);
        printf(" %s", kData.nama);
    }

    desain();
    char usrname[20];
    char passwrd[15];
    int found = 0;
    int correct = 0;

    gotoxy(93, 24);
    fgets(usrname, sizeof(usrname), stdin);
    usrname[strcspn(usrname, "\n")] = '\0';
    
    gotoxy(93, 29);
    fgets(passwrd, sizeof(passwrd), stdin);
    passwrd[strcspn(passwrd, "\n")] = '\0';

    while (fread(&kData, sizeof(kData), 1, karyawan) == 1) {
        if (strcmp(usrname, kData.nama) == 0) {
            found = 1;
            if (strcmp(passwrd, kData.pasword) == 0) {
                correct = 1;
                printf("LOGIN");    
            }
        }
    }
    if (!found) {
        printf("Username tidak ditemukan!");
    }
    if (!correct) {
        printf("Password salah!");
    }

    getchar();
    fclose(karyawan);

    return 0;
}