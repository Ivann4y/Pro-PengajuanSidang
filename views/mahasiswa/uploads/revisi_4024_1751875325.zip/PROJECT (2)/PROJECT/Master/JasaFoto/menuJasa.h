#include "addJasa.h"
#include "readJasa.h"
#include "updateJasa.h"
#include "deleteJasa.h"

void jselectMenu(int *pilihan) {

    int i;

    int pilih = 0;
    char *menus[] = {"Tambah Jasa", "Edit Jasa", "Hapus Jasa", "Tampilkan Jasa", "Keluar"};
    char key;
    int menuSize = sizeof(menus) / sizeof(menus[0]);

    while (1) {
        printf("Pilih Menu: \n");
        for (i = 0; i < menuSize; i++) {
            if (i == pilih) {
                printf(" ==> %s\n", menus[i]);
            } else {
                printf("    %s\n", menus[i]);
            }
        }

        key = getch();
        if (key == 72 && pilih > 0) {
            pilih--;
        } else if (key == 80 && pilih < menuSize - 1) {
            pilih++;
        } else if (key == 13) {
            *pilihan = pilih;
            break;
        }
        system("cls");
    }
}

void jselectedMenu(int pilihan) {
    switch (pilihan)
    {
    case 0:
        AddJasa();
        break;
    case 1:
        UpdateJasa();
        break;
    case 2:
        DeleteJasa();
        break;
    case 3:
        readJasa();
        break;
    case 4:
        //kembali ke login page
        break;
    }
}

int JasaMenu() {
    int pilih;
    system("cls");
    jselectMenu(&pilih);
    jselectedMenu(pilih);
    if (pilih == 4) {
        return 0;
    }
    printf("Kembali ke menu utama");
    getchar();
    JasaMenu();

    return 0;
}   