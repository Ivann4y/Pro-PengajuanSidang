#include "editJasa.h"

void jselectUpdate(int id, int *select);
void jselected(int sel, int toEdit);

int UpdateJasa() {
    FILE *bacaFile;
    FILE *updateFile;
    listJasa jData;
    int toEdit;
    int select;
    int found = 0;

    readJasa();

    bacaFile = fopen("DataJasa.dat", "rb");
    updateFile = fopen("DataJasa.dat", "rb+");
    fread(&jData, sizeof(jData), 1, bacaFile);
    printf("ID Jasa yang ingin diedit: K"); scanf("%d", &toEdit);

    while (fread(&jData, sizeof(jData), 1, bacaFile) == 1) {
        if (jData.id == toEdit || toEdit == 1) {
            found = 1;
            jselectUpdate(toEdit, &select);
            jselected(select, toEdit);
            printf("Data Jasa Berhasil Diupdate!");
            readJasa();
            break;
        }
    }

    if (!found) {
        printf("Data tidak ditemukan!");
    }

    fclose(bacaFile);
    fclose(updateFile);

    getchar();
    return 0;
}   

void jselectUpdate(int id, int *select) {
    int pilih = 0;
    char *mauUpdate[] = {"Nama", "Durasi", "Harga"};
    int menusize = sizeof(mauUpdate) / sizeof(mauUpdate[0]);
    char key;

    while (1) {
        printf("Pilih data yang ingin diedit K%d: ", id);
        for (int i = 0; i < 3; i++) {
            if (i == pilih) {
                printf(" ==> %s", mauUpdate[i]);
            } else {
                printf("    %s", mauUpdate[i]);
            }
        }

        key = getch();
        if (key == 72 && pilih > 0) {
            pilih--;
        } else if (key == 80 && pilih < menusize - 1) {
            pilih++;
        } else if (key == 13) {
            *select = pilih;
            break;
        }
    }
}

void jselected(int sel, int toEdit) {
    switch (sel)
    {
    case 0:
        jnama(toEdit);
        break;
    case 1:
        jdurasi(toEdit);
        break;
    case 2:
        jharga(toEdit);
        break;
    }
}