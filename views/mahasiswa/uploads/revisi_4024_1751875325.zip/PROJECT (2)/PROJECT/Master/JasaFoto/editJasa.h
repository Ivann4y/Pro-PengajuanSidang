listJasa JData;
FILE *read;
FILE *edit;

void jnama(int toedit) {
    char newName[50];

    int found = 0;
    read = fopen("DataJasa.dat", "rb");
    edit = fopen("DataJasa.dat", "rb+");

    while (fread(&JData, sizeof(JData), 1, read) == 1) {
        if (toedit == JData.id) {
            found = 1;
            printf("Data ditemukan!");+

            printf("Masukkan nama baru: "); scanf(" %[^\n]", &newName);
            strcpy(JData.nama, newName);
            fwrite(&JData, sizeof(JData), 1, edit);
        } else {
            fwrite(&JData, sizeof(JData), 1, edit);
        }
    }
    fclose(read);
    fclose(edit);
}

void jdurasi(int toedit) {
    int newNo;

    int found = 0;
    read = fopen("DataJasa.dat", "rb");
    edit = fopen("DataJasa.dat", "rb+");

    while (fread(&JData, sizeof(JData), 1, read) == 1) {
        if (toedit == JData.id) {
            found = 1;
            printf("Data ditemukan!");
            printf("Masukkan durasi baru: "); scanf("%d", &newNo);
            JData.durasi = newNo;
            fwrite(&JData, sizeof(JData), 1, edit);
        } else {
            fwrite(&JData, sizeof(JData), 1, edit);
        }
    }
    fclose(read);
    fclose(edit);
}

void jharga(int toedit) {
    int newhrg;

    int found = 0;
    read = fopen("DataJasa.dat", "rb");
    edit = fopen("DataJasa.dat", "rb+");

    while (fread(&JData, sizeof(JData), 1, read) == 1) {
        if (toedit == JData.id) {
            found = 1;
            printf("Data ditemukan!");
            printf("Masukkan harga baru: "); scanf("%d", &newhrg);
            JData.harga = newhrg;
            fwrite(&JData, sizeof(JData), 1, edit);
        } else {
            fwrite(&JData, sizeof(JData), 1, edit);
        }
    }
    fclose(read);
    fclose(edit);
}