#include <stdio.h>
#include <string.h>
#include <conio.h>
#include <stdlib.h>
#include <time.h>
#include <windows.h>


typedef struct 
{
    int id;
    char nama[50];
    int durasi;
    int harga;
} listJasa; 