int AddJasa() {
    listJasa jData;
    FILE *wList;
    wList = fopen("DataJasa.dat", "ab");
    
    int dataId = 0;
    char pilih;

    printf("===INPUT DATA JASA FOTO===");

    while (fread(&jData, sizeof(jData), 1, wList) == 1) {
        if (jData.id >= dataId) {
            dataId = jData.id;
        }
    }

    do {
        dataId = dataId + 1;
        printf("\nID Jasa: %d", dataId);
        jData.id = dataId;
        printf("\nNama Jasa: "); scanf(" %[^\n]", jData.nama);
        printf("\nDurasi: "); scanf("%d", &jData.durasi);
        printf("\nHarga: "); scanf("%d", &jData.harga);

        fwrite(&jData, sizeof(jData), 1, wList);
        printf("\nData berhasil ditambahkan!");
        printf("\nTambahkan data lagi? (y/n): "); scanf(" %c", &pilih);
        while (pilih != 'y' && pilih != 'Y' && pilih != 'n' && pilih != 'N') {
            printf("Input tidak valid! Masukkan input yang valid! (y/n): ");
            scanf(" %c", &pilih);
        }
    } while (pilih == 'y' || pilih == 'Y');

    return 0;
}