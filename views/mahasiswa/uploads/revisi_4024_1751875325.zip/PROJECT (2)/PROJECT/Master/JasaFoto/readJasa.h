int readJasa() {
    FILE *fileInt;
    listJasa JData;

    fileInt = fopen("DataJasa.dat", "rb");
    fread(&JData, sizeof(JData), 1, fileInt);
    printf("%-10s || %-20s || %-20s || %-20s \n", "ID", "Nama", "Durasi", "Harga");
    printf("====================================================================\n");
    while (!feof(fileInt))  
    {
        printf("%-10d || %-20s || %-20d || %-20d \n", JData.id, JData.nama, JData.durasi, JData.harga);
        fread(&JData, sizeof(JData), 1, fileInt);
    }
    fclose(fileInt);

    getchar();
    return 0;
}   