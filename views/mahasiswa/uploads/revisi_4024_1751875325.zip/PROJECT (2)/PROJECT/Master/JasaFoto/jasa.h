#include "menuJasa.h"

int jasa() {
    JasaMenu();
    return 0;
}