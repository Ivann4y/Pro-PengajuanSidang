void jtoTemporary(FILE *bacaData, FILE *temporary, int toDelete);
void jgiveBack(FILE *temp, FILE *tulisData);

int DeleteJasa () {
    FILE *aData;
    FILE *temporary;
    int toDelete;
    readJasa();
    printf("Masukkan ID yang ingin dihapus: J"); scanf("%d", &toDelete);
    jtoTemporary(aData, temporary, toDelete);
    jgiveBack(aData, temporary);

    getchar();

    return 0;
}

void jtoTemporary(FILE *bacaData, FILE *temporary, int toDelete) {
    listJasa jData;
    bacaData = fopen("DataJasa.dat", "rb");
    temporary = fopen("Temporary.dat", "wb");
    int found = 0;

    while (fread(&jData, sizeof(jData), 1, bacaData) == 1) {
        if (jData.id == toDelete) {
            found = 1;
            printf("Data berhasil dihapus!\n");
            continue;
        } else {
            fwrite(&jData, sizeof(jData), 1, temporary);
        }
    }

    if (!found) {
        printf("\nData tidak ditemukan!\n\n");
    }

    fclose(bacaData);
    fclose(temporary);
}

void jgiveBack(FILE *temp, FILE *tulisData) {
    listJasa jData;
    temp = fopen("Temporary.dat", "rb");
    tulisData = fopen("DataJasa.dat", "wb");

    while (fread(&jData, sizeof(jData), 1, temp) == 1) {
        fwrite(&jData, sizeof(jData), 1, tulisData);
    }

    fclose(temp);
    fclose(tulisData);
}