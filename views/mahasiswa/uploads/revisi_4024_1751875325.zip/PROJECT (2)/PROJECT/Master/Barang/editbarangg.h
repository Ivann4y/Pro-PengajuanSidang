dataBarang bData;
FILE *read;
FILE *edit;

void ppilihkategori1(char *kategori) {
    int pilih = 0;
    char *kategoris[] = {"Kamera", "Lensa", "Tripod", "Lightning"};
    int menusize = sizeof(kategoris) / sizeof(kategoris[0]);
    char key;

    while (1) {
        printf("Pilih data yang ingin dirubah: \n");

        for (int i = 0; i < menusize; i++) {
            if (i == pilih) {
                printf(" ==> %s\n", kategoris[i]);
            } else {
                printf("    %s\n", kategoris[i]);
            }
        }

        key = getch();
        if (key == 13) {
            break;
        } else if (key == 72 && pilih > 0) {
            pilih--;
        } else if (key == 80 && pilih < menusize - 1) {
            pilih++;
        }

        system("cls");    
    }

    strcpy(kategori, kategoris[pilih]);
}
void ppilihkategori2(char *status) {
    int pilih = 0;
    char *statuss[] = {"tersedia", "Disewakan", "Terjual"};
    int menusize = sizeof(statuss) / sizeof(statuss[0]);
    char key;

    while (1) {
        printf("Pilih data yang ingin dirubah: \n");

        for (int i = 0; i < menusize; i++) {
            if (i == pilih) {
                printf(" ==> %s\n", statuss[i]);
            } else {
                printf("    %s\n", statuss[i]);
            }
        }

        key = getch();
        if (key == 13) {
            break;
        } else if (key == 72 && pilih > 0) {
            pilih--;
        } else if (key == 80 && pilih < menusize - 1) {
            pilih++;
        }

        system("cls");    
    }

    strcpy(status, statuss[pilih]);
}

void bnama(int toedit) {
    char newName[50];

    int found = 0;
    read = fopen("DataBarang.dat", "rb");
    edit = fopen("DataBarang.dat", "rb+");

    while (fread(&bData, sizeof(bData), 1, read) == 1) {
        if (toedit == bData.id) {
            found = 1;
            printf("Data ditemukan!\n");
            printf("Masukkan nama baru: "); scanf(" %[^\n]", &newName);
            strcpy(bData.nama, newName);
            fwrite(&bData, sizeof(bData), 1, edit);
        } else {
            fwrite(&bData, sizeof(bData), 1, edit);
        }
    }
    fclose(read);
    fclose(edit);
}

void bkategori(int toedit) {

    int found = 0;
    read = fopen("DataBarang.dat", "rb");
    edit = fopen("DataBarang.dat", "rb+");

    while (fread(&bData, sizeof(bData), 1, read) == 1) {
        if (toedit == bData.id) {
            found = 1;
            printf("Data ditemukan!\n");
            getchar();
            ppilihkategori1(bData.kategori);
            fwrite(&bData, sizeof(bData), 1, edit);
        } else {
            fwrite(&bData, sizeof(bData), 1, edit);
        }
    }
    fclose(read);
    fclose(edit);
}

void bhargaSewa(int toedit) {
    int newhargaSewa;

    int found = 0;
    read = fopen("DataBarang.dat", "rb");
    edit = fopen("DataBarang.dat", "rb+");

    while (fread(&bData, sizeof(bData), 1, read) == 1) {
        if (toedit == bData.id) {
            found = 1;
            printf("Data ditemukan!\n");
            printf("Masukkan hargaSewa baru: "); scanf(" %d", &newhargaSewa);
            bData.hargaSewa = newhargaSewa;
            fwrite(&bData, sizeof(bData), 1, edit);
        } else {
            fwrite(&bData, sizeof(bData), 1, edit);
        }
    }
    fclose(read);
    fclose(edit);
}



void bhargaJual(int toedit) {
    int newhargaJual;

    int found = 0;
    read = fopen("DataBarang.dat", "rb");
    edit = fopen("DataBarang.dat", "rb+");

    while (fread(&bData, sizeof(bData), 1, read) == 1) {
        if (toedit == bData.id) {
            found = 1;
            printf("Data ditemukan!\n");
            printf("Masukkan harga jual baru: "); scanf("%d", &newhargaJual);
            bData.hargaJual = newhargaJual;
            fwrite(&bData, sizeof(bData), 1, edit);
        } else {
            fwrite(&bData, sizeof(bData), 1, edit);
        }
    }
    fclose(read);
    fclose(edit);
}

void bstatus(int toedit){

    int found = 0;
    read = fopen("DataBarang.dat", "rb");
    edit = fopen("DataBarang.dat", "rb+");

    while (fread(&bData, sizeof(bData), 1, read) == 1) {
        if (toedit == bData.id) {
            found = 1;
            printf("Data ditemukan!\n");
            ppilihkategori2(bData.status);
            fwrite(&bData, sizeof(bData), 1, edit);
        } else {
            fwrite(&bData, sizeof(bData), 1, edit);
        }
    }
    fclose(read);
    fclose(edit);

}