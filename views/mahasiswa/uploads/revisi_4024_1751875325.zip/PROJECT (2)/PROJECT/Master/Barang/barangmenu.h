#include "addbarangg.h"
#include "readbarangg.h"
#include "updatebarangg.h"
#include "deletebarangg.h"

void sselectMenu(int *pilihan) {
    int pilih = 0;
    char *menus[] = {"Tambah barang", "Update barang", "Hapus barang", "Tampilkan barang", "Keluar"};
    char key;
    int menuSize = sizeof(menus) / sizeof(menus[0]);

    while (1) {
        printf("Pilih Menu: \n"); 

        for (int i = 0; i < menuSize; i++) {
            if (i == pilih) {
                printf(" ==> %s\n", menus[i]);
            } else {
                printf("    %s\n", menus[i]);
            }
        }

        key = getch();
        if (key == 72 && pilih > 0) {
            pilih--;
        } else if (key == 80 && pilih < menuSize - 1) {
            pilih++;
        } else if (key == 13) {
            *pilihan = pilih;
            break;
        }

        system("cls");    
    }
}

void sselectedMenu(int pilihan) {
    switch (pilihan)
    {
    case 0:
        AddBarang();
        break;
    case 1:
        UpdateBarang();
        break;
    case 2:
        DeleteBarang();
        break;
    case 3:
        readBarang();
        break;
    case 4:
        exit(0);
        break;
    }
}


int menubarang() {
    int pilih;
    system("cls");
    sselectMenu(&pilih);
    sselectedMenu(pilih);
    if (pilih == 5) {
        return 0;
    }
    printf("Kembali ke menu utama");
    getchar();
    menubarang();

    return 0;
}