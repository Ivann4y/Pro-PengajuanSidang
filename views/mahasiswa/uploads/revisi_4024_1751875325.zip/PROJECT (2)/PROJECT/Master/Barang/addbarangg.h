void pilihkategori(char *kategori) {
    int pilih = 0;
    char *kategoris[] = {"Kamera", "Lensa", "Tripod", "Lightning"};
    int menusize = sizeof(kategoris) / sizeof(kategoris[0]);
    char key;

    while (1) {
        printf("Pilih kategori untuk Barang baru: \n");

        for (int i = 0; i < menusize; i++) {
            if (i == pilih) {
                printf(" ==> %s\n", kategoris[i]);
            } else {
                printf("    %s\n", kategoris[i]);
            }
        }

        key = getch();
        if (key == 13) {
            break;
        } else if (key == 72 && pilih > 0) {
            pilih--;
        } else if (key == 80 && pilih < menusize - 1) {
            pilih++;
        }

        system("cls");    
    }

    strcpy(kategori, kategoris[pilih]);
}

int AddBarang() {
    char nama[50];
    char kategori[15];
    dataBarang bData;
    FILE *baca;
    FILE *tulis;
    tulis = fopen("DataBarang.dat", "ab");
    baca = fopen("DataBarang.dat", "rb");

    int dataId = 0;
    char jawaban;

    printf("===INPUT DATA BARANG===\n");

    // Cari ID Barang terakhir
    while (fread(&bData, sizeof(bData), 1, baca) == 1) {
        if (bData.id >= dataId) {
            dataId = bData.id;
        }
    }
 
    do {
        // Tambahkan ID barang baru
        dataId = dataId + 1;
        printf("ID Barang baru: B%d\n", dataId);
        bData.id = dataId;

        // Masukkan nama barang
        printf("Masukan nama Barang baru: "); 
        scanf(" %[^]", &bData.nama);
        

        // Pilih kategori barang
        pilihkategori(kategori);
        strcpy(bData.kategori, kategori);

        // Masukkan harga sewa
        printf("Masukkan harga sewa: "); 
        scanf("%d", &bData.hargaSewa);

        // Masukkan harga jual
        printf("Masukkan harga jual: "); 
        scanf("%d", &bData.hargaJual);

        // Set status otomatis menjadi "Tersedia"
        strcpy(bData.status, "Tersedia");

        // Simpan data ke file
        fwrite(&bData, sizeof(bData), 1, tulis);
        printf("Barang baru telah ditambahkan!\n");

        // Tanyakan apakah ingin menambah barang lagi
        printf("Tambah Barang Lagi? (y/n): "); 
        scanf(" %c", &jawaban);

        while (jawaban != 'y' && jawaban != 'Y' && jawaban != 'n' && jawaban != 'N') {
            printf("Input tidak valid! Masukkan input yang valid! (y/n): ");
            scanf(" %c", &jawaban);
        }

        system("cls");
    } while (jawaban == 'y' || jawaban == 'Y');

    getch();
  
    fclose(baca);
    fclose(tulis);
    return 0;
}
