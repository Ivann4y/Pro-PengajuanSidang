#include <stdio.h>
#include <string.h>
#include <conio.h>
#include <stdlib.h>
#include <windows.h>
#include <stdbool.h>
#include <time.h>

typedef struct 
{
    int id;
    char nama[50];
    char kategori[15];
    int hargaSewa;
    int hargaJual;
    char status[20];

} dataBarang; 

typedef struct {
    int id;
    char nama[50];
    char kategori[15];
    int hargaJual;
    int hargaSewa;
    int jumlah;
    int total;
    char waktuJual[11];
    char waktuSewa[11];
    int penjualan;
    int penyewaan;

    } dataTransaksi;
