void ttoTemporary(FILE *bacaData, FILE *temporary, int toDelete);
void ggiveBack(FILE *temp, FILE *tulisData);

int DeleteBarang() {
    FILE *aData;
    FILE *temporary;
    int toDelete;
    readBarang();
    printf("Masukkan ID yang ingin dihapus:B"); scanf("%d", &toDelete);
    ttoTemporary(aData, temporary, toDelete);
    ggiveBack(aData, temporary);

    getchar();

    return 0;
}

void ttoTemporary(FILE *bacaData, FILE *temporary, int toDelete) {
    dataBarang bData;
    bacaData = fopen("DataBarang.dat", "rb");
    temporary = fopen("Temporary.dat", "wb");
    int found = 0; 
    int currentID = 1;

    while (fread(&bData, sizeof(bData), 1, bacaData) == 1) {
        if (bData.id == toDelete) {
            found = 1;
            printf("Data berhasil dihapus!\n");
            continue;
        } else {
            fwrite(&bData, sizeof(bData), 1, temporary);
        }
    }

    if (!found) {
        printf("\nData tidak ditemukan!\n\n");
    }

    fclose(bacaData);
    fclose(temporary);
}

void ggiveBack(FILE *temp, FILE *tulisData) {
    dataBarang bData;
    temp = fopen("Temporary.dat", "rb");
    tulisData = fopen("DataBarang.dat", "wb");

    while (fread(&bData, sizeof(bData), 1, temp) == 1) {
        fwrite(&bData, sizeof(bData), 1, tulisData);
    }

    fclose(temp);
    fclose(tulisData);
}