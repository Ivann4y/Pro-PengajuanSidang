#include "editbarangg.h"

void bselectUpdate(int id, int *select);
void bselected(int sel, int toEdit);

int UpdateBarang() {
    FILE *bacaFile;
    FILE *updateFile;
    dataBarang bdata;
    int toEdit;
    int select;
    int found = 0;

    readBarang();

    bacaFile = fopen("DataBarang.dat", "rb");
    updateFile = fopen("DataBarang.dat", "rb+");
    fread(&bdata, sizeof(bdata), 1, bacaFile);
    
    printf("\nID barang yang ingin diedit: B"); scanf("%d", &toEdit);

    while (fread(&bdata, sizeof(bdata), 1, bacaFile) == 1) {
        if (bdata.id == toEdit || toEdit == 1) {
            found = 1;
            bselectUpdate(toEdit, &select);
            bselected(select, toEdit);
            printf("\nData barang Berhasil Diupdate!\n\n");
            readBarang();
            break;
        }
    }

    if (!found) {
        printf("\nData tidak ditemukan!\n\n");
    }

    fclose(bacaFile);
    fclose(updateFile);

    getchar();
    return 0;
}   

void bselectUpdate(int id, int *select) {
    int pilih = 0;
    char *mauUpdate[] = {"Nama", "Kategori", "Harga sewa", "Harga Jual", "status"};
    int menusize = sizeof(mauUpdate) / sizeof(mauUpdate[0]);
    char key;

    while (1) {
        printf("Pilih role untuk barang B%d: \n", id);

        for (int i = 0; i < 4; i++) {
            if (i == pilih) {
                printf(" ==> %s\n", mauUpdate[i]);
            } else {
                printf("    %s\n", mauUpdate[i]);
            }
        }

        key = getch();
        if (key == 72 && pilih > 0) {
            pilih--;
        } else if (key == 80 && pilih < menusize - 1) {
            pilih++;
        } else if (key == 13) {
            *select = pilih;
            break;
        }

        system("cls");    
    }
}

void bselected(int sel, int toEdit) {
    switch (sel)
    {
    case 0:
        bnama(toEdit);
        break;
    case 1:
        bkategori(toEdit);
        break;
    case 2:
        bhargaSewa(toEdit);
        break;
    case 3:
        bhargaJual(toEdit);
        break;
    case 4:
        bstatus(toEdit);
        break;
    }
}