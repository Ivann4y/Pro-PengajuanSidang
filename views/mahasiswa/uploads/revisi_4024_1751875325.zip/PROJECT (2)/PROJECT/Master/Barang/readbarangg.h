int readBarang() {
    FILE *fileInt;
    dataBarang bdata;

    fileInt = fopen("DataBarang.dat", "rb");
    fread(&bdata, sizeof(bdata), 1, fileInt);
    printf("%-10s || %-20s || %-20s || %-20s || %-20s || %-20s ||\n", "ID", "Nama", "kategori", "Harga Sewa", "Harga Jual", "Status");
    printf("=============================================================================================================================\n");
    while (!feof(fileInt))
    {
        printf("%-10d || %-20s || %-20s || %-20d || %-20d || %-20s || \n", bdata.id, bdata.nama, bdata.kategori, bdata.hargaSewa, bdata.hargaJual, bdata.status);
        fread(&bdata, sizeof(bdata), 1, fileInt);
    }
    fclose(fileInt);

    _getch();
    return 0;
}   