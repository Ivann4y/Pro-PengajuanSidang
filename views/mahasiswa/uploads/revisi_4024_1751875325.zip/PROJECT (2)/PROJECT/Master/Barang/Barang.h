#include "barangmenu.h"

int barang() {
    menubarang();
    return 0;
}