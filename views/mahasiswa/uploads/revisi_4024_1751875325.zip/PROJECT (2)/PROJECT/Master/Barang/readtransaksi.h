int readtransaksi(){
    FILE *fileTransaksi = fopen("LaporanTransaksi.dat", "rb");
    dataTransaksi tdata;

    if (fileTransaksi == NULL) {
        printf("File tidak dapat dibuka!\n");
    }

    printf("%-5s || %-10s || %-10s || %-10s || %-10s || %-10s || %-10s || %-10s || \n", "ID", "Nama", "Kategori", "Harga Jual", "Jumlah", "Total", "waktu", "penjualan");
    printf("=============================================================================================================================\n");

    while (fread(&tdata, sizeof(tdata), 1, fileTransaksi) == 1) {
        printf("%-5d || %-10s || %-10s || %-10d || %-10d || %-10d || %-10s || %-10d || \n", tdata.id, tdata.nama, tdata.kategori, tdata.hargaJual, tdata.jumlah, tdata.total, tdata.waktuJual, tdata.penjualan);
    }

    fclose(fileTransaksi);

}