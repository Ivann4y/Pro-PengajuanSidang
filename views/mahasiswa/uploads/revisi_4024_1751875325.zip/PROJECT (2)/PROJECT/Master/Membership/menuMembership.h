//#include "headermember.h"
#include "addMembership.h"
#include "readMembership.h"
#include "updateMembership.h"
#include "deleteMembership.h"

void MselectMenu(int *pilihan){
    int pilih = 0;

    char *menus[] = {"Tambah Member", "Perbarui Member", "Hapus Member", "Tampilkan Member"};
    char mKey;
    int menuSize = sizeof(menus) / sizeof(menus[0]);
    
    while (1){
        printf("pilih Menu: \n");

        for (int i = 0; i < menuSize; i++){
            if (i == pilih){
                printf(" ==> %s\n", menus[i]);
            } else {
                printf("      %s\n", menus[i]);
            }
        }

        mKey = getch();
        if (mKey == 72 && pilih > 0){
            pilih--;
        } else if (mKey == 80 && pilih < menuSize -1){
            pilih++;
        } else if (mKey == 13){
            *pilihan = pilih;
            break;
        }

        system("cls");
    }
}

void MselectedMenu(int pilihan){
    switch (pilihan)
    {
        case 0:
            MtambahMember();
            break;
        case 1:
            MperbaruiMember();
            break;
        case 2:
            MhapusMember();
            break;
        case 3:
            MbacaMember();
            break;
    }
}

void MbalikMenu() {
    int pilih= 0;
    char *menus[] = {"Kembali ke menu utama", "Keluar"};
    int menuSize = sizeof(menus) / sizeof(menus[0]);
    char key;

    while (1) {

        printf("Pilih Menu: \n");

         for (int j = 0; j < 2; j++) {
            if (j == pilih) {
                printf(" ==> %s\n", menus[j]);
            } else {
                printf("     %s\n", menus[j]);
            }
        }

        key = getch();
        if (key == 72 && pilih > 0) {
            pilih--;
        } else if (key == 80 && pilih < menuSize - 1) {
            pilih++;
        } else if (key == 13) {
            break;
        }

        system("cls"); 
    }

    switch (pilih)
    {
        case 0:
            MselectMenu(&pilih);
            MselectedMenu(pilih);
            if (pilih != 6) {
                MbalikMenu();
            }
            break;
        case 1:
            exit(0);
            break;
    }
}

int MmenuMembership() {
    int pilih;
    FILE *mIdFile;
    int mInitialId = 0;

    mIdFile = fopen("LastID.dat", "r+b");
    if (mIdFile == NULL) {
        mIdFile = fopen("LastID.dat", "wb");
        fwrite(&mInitialId, sizeof(int), 1, mIdFile);
    }
    fclose(mIdFile);

    system("cls");
    MselectMenu(&pilih);
    MselectedMenu(pilih);
    if (pilih == 6){
        return 0;
    }
    MbalikMenu();

    return 0;
}