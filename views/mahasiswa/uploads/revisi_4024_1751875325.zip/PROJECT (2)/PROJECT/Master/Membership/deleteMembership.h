#include <stdio.h>

void MtoTemporary(FILE *mBacaData, FILE *mTemporary, int mToDelete);
void MgiveBack(FILE *mTemp, FILE *mTulisData);

void MhapusMember() {
    FILE *fileMember;
    FILE *mTempFile;
    datamember mdata;
    int mId;
    bool mFound = false;

    printf("Masukkan ID member yang ingin dihapus: ");
    scanf("%d", &mId);

    fileMember = fopen("DataMember.dat", "rb");
    mTempFile = fopen("TempMember.dat", "wb");

    if (fileMember == NULL || mTempFile == NULL) {
        printf("File tidak dapat dibuka!\n");
        return;
    }

    while (fread(&mdata, sizeof(mdata), 1, fileMember) == 1) {
        if (mdata.id !=  mId) {
            fwrite(&mdata, sizeof(mdata), 1, mTempFile);
        } else {
            mFound = true;
        }
    }

    fclose(fileMember);
    fclose(mTempFile);

    remove("DataMember.dat");
    rename("TempMember.dat", "DataMember.dat");

    if (mFound) {
        printf("Member dengan ID %d telah dihapus.\n",mId);
    } else {
        printf("Member dengan ID %d tidak ditemukan.\n", mId);
    }
}

void MtoTemporary(FILE *mBacaData, FILE *mTemporary, int mToDelete) {
    datamember tData;
    mBacaData = fopen("DataMember.dat", "rb");
    mTemporary = fopen("mTemporary.dat", "wb");
    if (mBacaData == NULL || mTemporary == NULL) {
        printf("File tidak dapat dibuka!\n");
        return;
    }
    int mFound = 0;

    while (fread(&tData, sizeof(tData), 1, mBacaData) == 1) {
        if (tData.id == mToDelete) {
            mFound = 1;
            printf("Data Berhasil dihapus!\n");
            continue;
        } else {
            fwrite(&tData, sizeof(tData), 1, mTemporary);
        }
    }

    if (!mFound) {
        printf("\nData tidak ditemukan!\n\n");
    }

    fclose(mBacaData);
    fclose(mTemporary);
}

void MgiveBack(FILE *mTemp, FILE *mTulisData) {
    datamember tData;
    mTemp = fopen("mTemporary.dat", "rb");
    mTulisData = fopen("DataMember.dat", "wb");
    if (mTemp == NULL || mTulisData == NULL) {
        printf("File tidak dapat dibuka!\n");
        return;
    }

    while (fread(&tData, sizeof(tData), 1, mTemp) == 1) {
        fwrite(&tData, sizeof(tData), 1, mTulisData);
    }
    fclose(mTemp);
    fclose(mTulisData);
}
