int MbacaMember(){
    FILE *mFileINt;
    datamember mRData;
    bool mIsEmpty = true;

    mFileINt = fopen("DataMember.dat", "rb");
    if (mFileINt == NULL) {
        printf("File tidak dapat dibuka!\n");
        return -1;
    }

    while (fread(&mRData, sizeof(mRData), 1, mFileINt) == 1) {
        if (mIsEmpty) {
            printf("||============||======================||======================||======================||======================||\n");
            printf("|| %-10s || %-20s || %-20s || %-20s || %-20s || \n", "ID", "Nama", "No Telp", "Tanggal Join", "Tanggal Kadaluarsa");
            printf("||============||======================||======================||======================||======================||\n");
            mIsEmpty = false;
        }
        printf("|| %-10d || %-20s || %-20s || %-20s || %-20s || \n", mRData.id, mRData.nama, mRData.noTelp, mRData.tgglJoin, mRData.kadaluarsa);
    }

    if (mIsEmpty) {
        printf("Tidak ada member yang ditemukan.\n");
    } else {
        printf("||============||======================||======================||======================||======================||\n");
    }

    fclose(mFileINt);
    getchar();
    return 0;
}
