datamember eData;
FILE *Read;
FILE *Edit;

void Mnama(int mToEdit) {
    char mNewName[50];
    int mFound = 0;

    Read = fopen("DataMember.dat", "rb");
    Edit = fopen("DataMember.dat", "rb+");
    if (Read == NULL || Edit == NULL) {
        printf("File tidak dapat dibuka!\n");
        return;
    }

    while (fread(&eData, sizeof(eData), 1, Read) == 1) {
        if (mToEdit == eData.id) {
            mFound = 1;
            printf("Data telah ditemukan!\n");
            printf("Masukkan Nama Baru: "); scanf(" %[^\n]", mNewName);
            strcpy(eData.nama, mNewName);
            fseek(Edit, -sizeof(eData), SEEK_CUR); // pindahkan pointer file kembali untuk mengupdate record
            fwrite(&eData, sizeof(eData), 1, Edit);
            break;
        }
    }

    if (!mFound) {
        printf("Member dengan ID %d tidak ditemukan!\n", mToEdit);
    }

    fclose(Read);
    fclose(Edit);
}

void MnoTelp(int mToEdit) {
    char mNewNom[15];
    int mFound = 0;

    Read = fopen("DataMember.dat", "rb");
    Edit = fopen("DataMember.dat", "rb+");
    if (Read == NULL || Edit == NULL) {
        printf("File tidak dapat dibuka!\n");
        return;
    }

    while (fread(&eData, sizeof(eData), 1, Read) == 1) {
        if (mToEdit == eData.id) {
            mFound = 1;
            printf("Data ditemukan!\n");
            printf("Masukkan nomor telepon baru: "); scanf("%14s", mNewNom);
            strcpy(eData.noTelp, mNewNom);
            fseek(Edit, -sizeof(eData), SEEK_CUR); // pindahkan pointer file kembali untuk mengupdate record
            fwrite(&eData, sizeof(eData), 1, Edit);
            break;
        }
    }

    if (!mFound) {
        printf("Member dengan ID %d tidak ditemukan!\n", mToEdit);
    }

    fclose(Read);
    fclose(Edit);
}











