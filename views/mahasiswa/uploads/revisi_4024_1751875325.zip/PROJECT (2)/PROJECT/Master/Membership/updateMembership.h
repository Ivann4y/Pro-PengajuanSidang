#include "editMembership.h"

void MselectUpdate(int id, int *mSelect);
void Mselected(int mSel, int mToEdit);

int MperbaruiMember(){
    FILE *mBacaFile;
    FILE *mUpdateFile;
    datamember MuData;
    int mToEdit;
    int mSelect;
    int mFound = 0;

    MbacaMember();

    mBacaFile = fopen("DataMember.dat", "rb");
    mUpdateFile = fopen("DataMember.dat", "rb+");
    if (mBacaFile == NULL || mUpdateFile == NULL) {
        printf("File tidak dapat dibuka!\n");
        return -1;
    }

    printf("\nID Member yang ingin diedit: M"); scanf("%d", &mToEdit);

    while (fread(&MuData, sizeof(MuData), 1, mBacaFile) == 1) {
        if (MuData.id == mToEdit){
            mFound = 1;
            MselectUpdate(mToEdit, &mSelect);
            Mselected(mSelect, mToEdit);
            printf("\nData Member Berhasil DiUpdate!\n\n");
            MbacaMember();
            break;
        }
    }

    if (!mFound) {
        printf("\nData tidak ditemukan!\n\n");
    }

    fclose(mBacaFile);
    fclose(mUpdateFile);

    getchar();
    return 0;
}

void MselectUpdate(int id, int *mSelect){
    int mPilih = 0;
    char *mMauUpdate[] = {"Nama", "Nomor Telepon"};
    int mMenuSize = sizeof(mMauUpdate) / sizeof(mMauUpdate[0]);
    char mKey;

    while (1) {
        for (int i = 0; i < 2; i++) {
            if (i == mPilih){
                printf(" ==> %s\n", mMauUpdate[i]);
            } else {
                printf("      %s\n", mMauUpdate[i]);
            }
        }

        mKey = getch();
        if (mKey == 72 && mPilih > 0) {
            mPilih--;
        } else if (mKey == 80 && mPilih < mMenuSize - 1) {
            mPilih++;
        } else if (mKey == 13) {
            *mSelect = mPilih;
            break;
        }

        system("cls");
    }
}

void Mselected(int mSel, int mToEdit){
    switch (mSel)
    {
    case 0:
        Mnama(mToEdit);
        break;
    case 1:
        MnoTelp(mToEdit);
        break;
    }
}
