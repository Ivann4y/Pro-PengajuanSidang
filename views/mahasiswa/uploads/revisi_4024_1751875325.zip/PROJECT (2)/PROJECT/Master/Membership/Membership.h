#include "menuMembership.h"

int Mmember() {
    MmenuMembership();
    return 0;
}