#include <stdio.h>
#include <string.h>
#include <conio.h>
#include <stdlib.h>
#include <time.h>
#include <windows.h>
#include <stdbool.h>

typedef struct {
    int id;
    char nama[50];
    char noTelp[15];
    char tgglJoin[11];
    char kadaluarsa[11];
} datamember;

typedef struct {
    int id;
    char nama[50];
    int tahun;
    int total;
    char tanggal[11];
} dataTransaksi;
