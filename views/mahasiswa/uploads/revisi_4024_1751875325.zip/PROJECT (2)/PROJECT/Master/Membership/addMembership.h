int MtambahMember()
{
    datamember rData;
    FILE *Baca;
    FILE *mTulis;
    FILE *mIdFile;
    mTulis = fopen("DataMember.dat", "ab");
    Baca = fopen("DataMember.dat", "rb");
    mIdFile = fopen("LastID.dat", "r+b");
    if (Baca == NULL || mTulis == NULL || mIdFile == NULL)
    {
        printf("File tidak dapat dibuka!\n");
        return -1;
    }

    int mDataId = 0;
    char mJawaban;
    int mTotalPerTahun = 50000; // Harga untuk satu tahun
    int mTotal, mTahunBayar;
    time_t t = time(NULL);
    struct tm *currentTime = localtime(&t);
    struct tm expiryTime;

    fread(&mDataId, sizeof(int), 1, mIdFile);

    printf("===INPUT DATA MEMBERSHIP===\n");

    do
    {
        mDataId = mDataId + 1;

        printf("ID Member baru: M%d\n", mDataId);

        rData.id = mDataId;
        printf("Masukkan nama membership baru: ");
        scanf(" %[^\n]", &rData.nama);
        printf("Masukkan Nomor Telepon: ");
        scanf(" %s", &rData.noTelp);

        strftime(rData.tgglJoin, sizeof(rData.tgglJoin), "%d-%m-%Y", currentTime);

        printf("Berapa Tahun Member Ingin Berlangganan?: ");
        scanf("%d", &mTahunBayar);

        mTotal = mTotalPerTahun * mTahunBayar;

        expiryTime = *currentTime;
        expiryTime.tm_year += mTahunBayar;
        mktime(&expiryTime);
        strftime(rData.kadaluarsa, sizeof(rData.kadaluarsa), "%d-%m-%Y", &expiryTime);

        fwrite(&rData, sizeof(rData), 1, mTulis);

        printf("\n+++ Member baru telah ditambahkan +++\n");
        printf("+++ Tanggal Join: %s +++\n", rData.tgglJoin);
        printf("+++ Tanggal kadaluarsa: %s +++\n", rData.kadaluarsa);

        printf("Tambah Member Lagi? (y/n): ");
        scanf(" %c", &mJawaban);

        while (mJawaban != 'y' && mJawaban != 'Y' && mJawaban != 'n' && mJawaban != 'N')
        {
            printf("Input tidak valid! Masukkan input yang valid! (y/n): ");
            scanf(" %c", &mJawaban);
        }

        system("cls");

    } while (mJawaban == 'y' || mJawaban == 'Y');

    // Update pemilik id terakhir
    fseek(mIdFile, 0, SEEK_SET);
    fwrite(&mDataId, sizeof(int), 1, mIdFile);

    fclose(Baca);
    fclose(mTulis);
    fclose(mIdFile);
    return 0;
}