void kpilihRole(char *role) {
    int pilih = 0;
    char *roles[] = {"Administrator", "Counter", "Management", "Fotografer", "QC"};
    int menusize = sizeof(roles) / sizeof(roles[0]);
    char key;

    while (1) {
        desainAdmin();
        gotoxy(40,16);
        printf("Pilih role untuk karyawan baru: ");
        y = 16;
        for (int i = 0; i < 5; i++) {
            gotoxy(40,y+1);
            if (i == pilih) {
                printf(" ==> %s", roles[i]);
            } else {
                printf("    %s", roles[i]);
            }
            y++;
        }

        key = getch();
        if (key == 13) {
            break;
        } else if (key == 72 && pilih > 0) {
            pilih--;
        } else if (key == 80 && pilih < menusize - 1) {
            pilih++;
        }

        // Clear only the role selection part of the screen
        for (int i = 0; i < 5; i++) {
            gotoxy(40, 17 + i);
            printf("                          "); // Clear the line
        }
    }

    strcpy(role, roles[pilih]);
}
          
int AddKaryawan() {
    dataKaryawan kData;
    FILE *baca;
    FILE *tulis;
    tulis = fopen("DataKaryawan.dat", "ab");
    baca = fopen("DataKaryawan.dat", "rb");

    int dataId = 0;
    char jawaban;

    printf("===INPUT DATA KARYAWAN===");

    while (fread(&kData, sizeof(kData), 1, baca) == 1) {
        if (kData.id >= dataId) {
            dataId = kData.id;
        }
    }

    do{
        dataId = dataId+1;
    //input data karyawanm
        gotoxy(40, 11);
        printf("ID karyawan baru: K%d", dataId);
        //printf("ID karyawan baru: K"); scanf("%d", kData.id);
        kData.id = dataId;
        gotoxy(40,12);
        printf("Masukan nama karyawan baru: "); scanf(" %[^\n]", &kData.nama);
        gotoxy(40,13);
        printf("Masukkan Password: "); scanf(" %s", &kData.pasword);
        gotoxy(40,14);
        printf("Masukkan Nomor Telepon: "); scanf(" %d", &kData.notelp);

        kpilihRole(kData.role);

        strcpy(kData.status, "Aktif");
        
        fwrite(&kData, sizeof(kData), 1, tulis);
        gotoxy(40,23);
        printf("Karyawan Telah ditambahkan!");
        //dataId++;
        gotoxy(40,24);
        printf("Tambah Karyawan Lagi? (y/n): "); scanf(" %c", &jawaban);

        while (jawaban != 'y' && jawaban != 'Y' && jawaban != 'n' && jawaban != 'N') {
            gotoxy(40,25);
            printf("Input tidak valid! Masukkan input yang valid! (y/n): ");
            scanf(" %c", &jawaban);
        }

        system("cls");
    } while(jawaban == 'y' || jawaban == 'Y');
  
    fclose(baca);
    fclose(tulis);
    return 0;

}