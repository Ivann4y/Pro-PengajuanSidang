//#include "../../heading.h"
#include "addKaryawan.h"
#include "readKaryawan.h"
#include "updateKaryawan.h"
#include "deleteKaryawan.h"

int x, y, i, j;
int toDelete;

void kselectMenu(int *pilihan) {

    int pilih = 0;
    char *menus[] = {"Tambah Karyawan", "Update Karyawan", "Hapus Karyawan", "Tampilkan Karyawan", "Keluar"};
    char key;
    int menuSize = sizeof(menus) / sizeof(menus[0]);

    while (1) {
        desainAdmin();
        gotoxy(1, 8);
        printf("Pilih Menu: ");
        y = 9;
        for (i = 0; i < menuSize; i++) {
            gotoxy(1, y+1);
            if (i == pilih) {
                printf(" ==> %s", menus[i]);
            } else {
                printf("    %s", menus[i]);
            }
            y++;
        }

        key = getch();
        if (key == 72 && pilih > 0) {
            pilih--;
        } else if (key == 80 && pilih < menuSize - 1) {
            pilih++;
        } else if (key == 13) {
            *pilihan = pilih;
            break;
        }

        // Clear the screen without using system("cls")
        for (int k = 8; k <= y; k++) {
            gotoxy(1, k);
            printf("                              ");
        }
        gotoxy(1, 8);
    }
}

void kselectedMenu(int pilihan) {
    switch (pilihan)
    {
    case 0:
        gotoxy(40, 10);
        AddKaryawan();
        break;
    case 1:
        gotoxy(40, 10);
        UpdateKaryawan();
        break;
    case 2:
        gotoxy(40, 10);
        DeleteKaryawan();
        break;
    case 3:
        gotoxy(40, 10);
        readKaryawan();
        break;
    case 4:
        //kembali ke login page
        break;
    }
}

int KaryawanMenu() {
    int pilih;
    system("cls");
    kselectMenu(&pilih);
    kselectedMenu(pilih);
    if (pilih == 4) {
        return 0;
    }
    gotoxy(40, 30);
    printf("Kembali ke menu utama");
    getchar();
    KaryawanMenu();

    return 0;
}   