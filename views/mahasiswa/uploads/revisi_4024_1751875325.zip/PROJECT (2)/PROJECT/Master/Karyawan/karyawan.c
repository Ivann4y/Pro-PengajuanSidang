#include "menuKaryawan.h"

int main() {
    KaryawanMenu();
    return 0;
}