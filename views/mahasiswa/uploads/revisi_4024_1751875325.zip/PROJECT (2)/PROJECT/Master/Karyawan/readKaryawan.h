int l = 13;

int readKaryawan() {
    FILE *fileInt;
    dataKaryawan kdata;

    fileInt = fopen("DataKaryawan.dat", "rb");
    fread(&kdata, sizeof(kdata), 1, fileInt);
    printf("|| %-10s || %-20s || %-20s || %-20s || \n", "ID", "Nama", "Role", "Status");
    gotoxy(40, 11);
    printf("======================================================\n");
    y = 12;
    while (!feof(fileInt))
    {
        gotoxy(40, y+1);
        printf("|| %-10d || %-20s || %-20s || %-20s ||\n", kdata.id, kdata.nama, kdata.role, kdata.status);
        fread(&kdata, sizeof(kdata), 1, fileInt);
        y++;
        l++;
    }
    fclose(fileInt);

    getchar();
    return 0;
}   