#include "menuKaryawan.h"

int karyawan() {
    KaryawanMenu();
    return 0;
}