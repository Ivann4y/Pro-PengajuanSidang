#include <stdio.h>
#include <string.h>
#include <conio.h>
#include <stdlib.h>
#include <time.h>
#include <windows.h>


typedef struct 
{
    int id;
    char nama[50];
    char pasword[20];
    char role[15];
    int notelp;
} dataKaryawan; 