#include "editKaryawan.h"

void kselectUpdate(int id, int *select);
void kselected(int sel, int toEdit);

int UpdateKaryawan() {
    FILE *bacaFile;
    FILE *updateFile;
    dataKaryawan kdata;
    int toEdit;
    int select;
    int found = 0;

    readKaryawan();

    bacaFile = fopen("DataKaryawan.dat", "rb");
    updateFile = fopen("DataKaryawan.dat", "rb+");
    fread(&kdata, sizeof(kdata), 1, bacaFile);
    gotoxy(40, l+1);
    printf("ID karyawan yang ingin diedit: K"); scanf("%d", &toEdit); l+1;

    while (fread(&kdata, sizeof(kdata), 1, bacaFile) == 1) {
        if (kdata.id == toEdit || toEdit == 1) {
            found = 1;
            kselectUpdate(toEdit, &select);
            kselected(select, toEdit);
            gotoxy(40, l+1);
            printf("Data Karyawan Berhasil Diupdate!"); l+1;
            readKaryawan();
            break;
        }
    }

    if (!found) {
        gotoxy(40, l+1);
        printf("Data tidak ditemukan!");
    }

    fclose(bacaFile);
    fclose(updateFile);

    getchar();
    return 0;
}   

void kselectUpdate(int id, int *select) {
    int pilih = 0;
    char *mauUpdate[] = {"Nama", "Password", "Role", "No.Telp"};
    int menusize = sizeof(mauUpdate) / sizeof(mauUpdate[0]);
    char key;

    while (1) {
        gotoxy(40, l+1);
        printf("Pilih data yang ingin diedit K%d: ", id); l+1;
        y = l+1;
        for (int i = 0; i < 4; i++) {
            gotoxy(40, y+1);
            if (i == pilih) {
                printf(" ==> %s", mauUpdate[i]);
            } else {
                printf("    %s", mauUpdate[i]);
            }
            y++;
        }

        key = getch();
        if (key == 72 && pilih > 0) {
            pilih--;
        } else if (key == 80 && pilih < menusize - 1) {
            pilih++;
        } else if (key == 13) {
            *select = pilih;
            break;
        }

        // Clear the previous menu output without clearing the entire screen
        for (int i = 0; i < 4; i++) {
            gotoxy(40, l+1 + i + 1);
            printf("                          "); // Clear line
        }
    }
}

void kselected(int sel, int toEdit) {
    switch (sel)
    {
    case 0:
        knama(toEdit);
        break;
    case 1:
        kpassword(toEdit);
        break;
    case 2:
        krole(toEdit);
        break;
    case 3:
        knoTelp(toEdit);
        break;
    }
}