void ktoTemporary(FILE *bacaData, FILE *temporary, int toDelete);
void kgiveBack(FILE *temp, FILE *tulisData);

int DeleteKaryawan () {
    FILE *aData;
    FILE *temporary;
    int toDelete;
    readKaryawan();
    printf("Masukkan ID Karyawan: K"); scanf("%d", &toDelete);
    ktoTemporary(aData, temporary, toDelete);
    kgiveBack(aData, temporary);

    getchar();

    return 0;
}

void ktoTemporary(FILE *bacaData, FILE *temporary, int toDelete) {
    dataKaryawan kData;
    bacaData = fopen("DataKaryawan.dat", "rb");
    temporary = fopen("Temporary.dat", "wb");
    int found = 0;

    while (fread(&kData, sizeof(kData), 1, bacaData) == 1) {
        if (kData.id == toDelete) {
            found = 1;
            printf("Data berhasil dihapus!\n");
            continue;
        } else {
            fwrite(&kData, sizeof(kData), 1, temporary);
        }
    }

    if (!found) {
        printf("\nData tidak ditemukan!\n\n");
    }

    fclose(bacaData);
    fclose(temporary);
}

void kgiveBack(FILE *temp, FILE *tulisData) {
    dataKaryawan kData;
    temp = fopen("Temporary.dat", "rb");
    tulisData = fopen("DataKaryawan.dat", "wb");

    while (fread(&kData, sizeof(kData), 1, temp) == 1) {
        fwrite(&kData, sizeof(kData), 1, tulisData);
    }

    fclose(temp);
    fclose(tulisData);
}