dataKaryawan KData;
FILE *read;
FILE *edit;

void kpilihRole1(char *role) {
    int pilih = 0;
    char *roles[] = {"Administrator", "Counter", "Management", "Fotografer", "QC"};
    int menusize = sizeof(roles) / sizeof(roles[0]);
    char key;

    while (1) {
        gotoxy(40,l+1);
        printf("Pilih role untuk karyawan: ");
        y = 22;
        for (int i = 0; i < 5; i++) {
            gotoxy(40,y+1);
            if (i == pilih) {
                printf(" ==> %s", roles[i]);
            } else {
                printf("    %s", roles[i]);
            }
        }

        key = getch();
        if (key == 13) {
            break;
        } else if (key == 72 && pilih > 0) {
            pilih--;
        } else if (key == 80 && pilih < menusize - 1) {
            pilih++;
        }

        system("cls");    
    }

    strcpy(role, roles[pilih]);
}

void knama(int toedit) {
    char newName[50];

    int found = 0;
    read = fopen("DataKaryawan.dat", "rb");
    edit = fopen("DataKaryawan.dat", "rb+");

    while (fread(&KData, sizeof(KData), 1, read) == 1) {
        if (toedit == KData.id) {
            found = 1;
            gotoxy(40, 20);
            printf("Data ditemukan!");
            gotoxy(40, 21);
            printf("Masukkan nama baru: "); scanf(" %[^\n]", &newName);
            strcpy(KData.nama, newName);
            fwrite(&KData, sizeof(KData), 1, edit);
        } else {
            fwrite(&KData, sizeof(KData), 1, edit);
        }
    }
    fclose(read);
    fclose(edit);
}

void kpassword(int toedit) {
    char newPass[50];

    int found = 0;
    read = fopen("DataKaryawan.dat", "rb");
    edit = fopen("DataKaryawan.dat", "rb+");

    while (fread(&KData, sizeof(KData), 1, read) == 1) {
        if (toedit == KData.id) {
            found = 1;
            gotoxy(40, 20);
            printf("Data ditemukan!");
            gotoxy(40, 21);
            printf("Masukkan password baru: "); scanf(" %s", &newPass);
            strcpy(KData.pasword, newPass);
            fwrite(&KData, sizeof(KData), 1, edit);
        } else {
            fwrite(&KData, sizeof(KData), 1, edit);
        }
    }
    fclose(read);
    fclose(edit);
}

void krole(int toedit) {
    char newName[50];

    int found = 0;
    read = fopen("DataKaryawan.dat", "rb");
    edit = fopen("DataKaryawan.dat", "rb+");

    while (fread(&KData, sizeof(KData), 1, read) == 1) {
        if (toedit == KData.id) {
            found = 1;
            gotoxy(40, 20);
            printf("Data ditemukan!");
            kpilihRole1(KData.role);
            fwrite(&KData, sizeof(KData), 1, edit);
        } else {
            fwrite(&KData, sizeof(KData), 1, edit);
        }
    }
    fclose(read);
    fclose(edit);
}

void knoTelp(int toedit) {
    int newNo;

    int found = 0;
    read = fopen("DataKaryawan.dat", "rb");
    edit = fopen("DataKaryawan.dat", "rb+");

    while (fread(&KData, sizeof(KData), 1, read) == 1) {
        if (toedit == KData.id) {
            found = 1;
            gotoxy(40, 20);
            printf("Data ditemukan!");
            gotoxy(40, 21);
            printf("Masukkan nomor telpon baru: "); scanf("%d", &newNo);
            KData.notelp = newNo;
            fwrite(&KData, sizeof(KData), 1, edit);
        } else {
            fwrite(&KData, sizeof(KData), 1, edit);
        }
    }
    fclose(read);
    fclose(edit);
}