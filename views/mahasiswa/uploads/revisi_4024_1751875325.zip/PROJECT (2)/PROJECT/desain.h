int x, y, i;

int getTerminalWidth() {
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    if (GetConsoleScreenBufferInfo(GetStdHandle(STD_OUTPUT_HANDLE), &csbi)) {
        return csbi.srWindow.Right - csbi.srWindow.Left + 1;
    }
    return 80; // Default width
}

int getTerminalHeight() {
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    if (GetConsoleScreenBufferInfo(GetStdHandle(STD_OUTPUT_HANDLE), &csbi)) {
        return csbi.srWindow.Bottom - csbi.srWindow.Top + 1;
    }
    return 25; // Default height
}

void setFullscreen() {
    HWND hwnd = GetConsoleWindow();
    ShowWindow(hwnd,SW_MAXIMIZE);
}



void gotoxy(int x, int y) {
    COORD c;
    c.X = x;
    c.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), c);
}

void SetColor(unsigned short color)
{
    HANDLE hConsoleOutput = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsoleOutput,color);
}

void PrintFile(char file[], int x, int y)
{
    FILE *Text;
    char Data[1000000];
    if((Text=fopen(file, "r")) == NULL)
    {
        system("cls");
    }
    while(fgets(Data, 1000000, Text))
    {
        gotoxy(x, y);
        printf("%s", Data);
        y++;
    }
    fclose(Text);
}

void desainLogin() {
    int lebar = getTerminalWidth();
    int tinggi = getTerminalHeight();

    gotoxy(10,10);
    printf("lebar: %d, tinggi: %d", lebar, tinggi);

    //border full
    for (x = 0; x < 211; x++) {
        for (int i = 0; i < 2; i++) {
            gotoxy(x, i);
            printf("%c", 177);
        }
        for (int i = 51; i > 49; i--) {
            gotoxy(x, i);
            printf("%c", 177);
        }
    }
    for (y = 0; y < 51; y++) {
        for(int i = 0; i < 4; i++) {
            gotoxy(i, y);
            printf("%c", 177);
        }
        for (int i = 211; i > 206; i--) {
            gotoxy(i, y);
            printf("%c", 177);
        }
    }

    PrintFile("ASCII/login.txt", 88, 12);
    
    //border login
    for (x = 70; x < 140; x++) {
        gotoxy(x, 20);
        printf("%c", 177);
        gotoxy(x, 33);
        printf("%c", 177);
    }
    for (y = 20; y < 33; y++) {
        for (int i = 70; i < 72; i++) {
            gotoxy(i, y);
            printf("%c", 177);
        }
        for (int i = 139; i > 137; i--) {
            gotoxy(i, y);
            printf("%c", 177);
        }
    }

    PrintFile("ASCII/kamera3.txt", 130, 12);
    PrintFile("ASCII/kamera3.txt", 70, 12);
    PrintFile("ASCII/kamera2.txt", 155, 18);

    //kolom username
    gotoxy(83, 24);
    printf("Username: ");
    for (x = 80; x < 130; x++) {
        gotoxy(x, 22);
        printf("_");
        gotoxy(x, 25);
        printf("_");
    }
    for (y = 23; y < 26; y++) {
        gotoxy(80, y);
        printf("|");
        gotoxy(130, y);
        printf("|");
    }

    //kolom password
    gotoxy(83, 29);
    printf("Password: ");
    for (x = 80; x < 130; x++) {
        gotoxy(x, 27);
        printf("_");
        gotoxy(x, 30);
        printf("_");
    }
    for (y = 28; y < 31; y++) {
        gotoxy(80, y);
        printf("|");
        gotoxy(130, y);
        printf("|");
    }

    gotoxy(93,24);
}

void desainAdmin() {
    PrintFile("ASCII/photo.txt", 10, 0);

    for (x = 0; x < 150; x++) {
        gotoxy(x, 6);
        printf("%c",177);
    }

    for (y = 7; y < 85; y++) {
        gotoxy(30, y+1);
        printf("%c%c",177,177);
    }
}