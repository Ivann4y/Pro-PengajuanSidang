#include  "../../Master/Membership/headermember.h"

int MreadTransaksi() {
    FILE *mFileTransaksi;
    FILE *mFileMember;
    dataTransaksi tdata;
    datamember mdata;
    int mTotalRevenue = 0;
    int mTotalMember = 0;

    mFileTransaksi = fopen("LaporanTransaksi.dat", "rb");
    if (mFileTransaksi == NULL) {
        printf("File tidak dapat dibuka!\n");
        return -1;
    }

    mFileMember;  fopen("DataMember.dat", "rb");
    if (mFileMember == NULL) {
        printf("File tidak dapat dibuka!\n");
        fclose(mFileTransaksi);
        return -1;
    }

    printf("||============||============||======================||============||============||\n");
    printf("|| %-10s || %-10s || %-20s || %-10s || %-10s || \n", "ID Trans", "ID Member", "Nama", "Tanggal", "Total");
    printf("||============||============||======================||============||============||\n");

    while (fread(&tdata, sizeof(tdata), 1, mFileTransaksi) == 1) {
        printf("|| %-10d || %-10d || %-20s || %-10s || Rp.%-10d || \n", tdata.mId, tdata.mId, tdata.mNama, tdata.mTanggal, tdata.mTotal);
        mTotalRevenue += tdata.mTotal;
        mTotalMember++;
    }

    printf("||============||============||======================||============||============||\n");
    printf("Total Member: %d\n", mTotalMember);
    printf("Total Pendapatan: Rp.%d\n", mTotalRevenue);

    fclose(mFileTransaksi);
    fclose(mFileMember);

    getchar();
    return 0;
}