#include  "../../Master/Membership/headermember.h"

void MsimpanTransaksi(datamember member, int mTahun, int mTotal, const char* mTanggal);
void MprosesTransaksi(datamember member, int mTotal, const char* mTanggal);
void MtransaksiMember();
void MbacaMemberTransaksi();

void MsimpanTransaksi(datamember member, int mTahun, int mTotal, const char* mTanggal) {
    FILE *mFileTransaksi;
    FILE *mIdFile;
    dataTransaksi tdata;
    int mDataId = 0;

    mFileTransaksi = fopen("LaporanTransaksi.dat", "ab");
    mIdFile = fopen("LastTransID.dat", "r+b");
    if (mFileTransaksi == NULL || mIdFile == NULL) {
        printf("File tidak dapat dibuka!\n");
        return;
    }

    fread(&mDataId, sizeof(int), 1, mIdFile);
    mDataId = mDataId + 1;

    tdata.mId = mDataId;
    strcpy(tdata.mNama, member.mNama); // Ensure the name is correctly copied
    tdata.mTahun = mTahun;
    tdata.mTotal = mTotal;
    strcpy(tdata.mTanggal, mTanggal); // Set the transaction date

    fwrite(&tdata, sizeof(tdata), 1, mFileTransaksi);

    fseek(mIdFile, 0, SEEK_SET);
    fwrite(&mDataId, sizeof(int), 1, mIdFile);

    fclose(mFileTransaksi);
    fclose(mIdFile);
}

void MtransaksiMember() {
    int mTahun, mBulan, mHari;
    datamember member;
    int mTotal = 50000; // Harga untuk satu mTahun
    int mUangDiterima, mUangKembalian;
    FILE *mFileInt;
    bool mFound = false;
    int mSearchId;
    char mTanggal[11];
    char mKey;

    printf("Masukkan ID member: ");
    scanf("%d", &mSearchId);

    mFileInt = fopen("DataMember.dat", "rb");
    if (mFileInt == NULL) {
        printf("File tidak dapat dibuka!\n");
        return;
    }

    while (fread(&member, sizeof(member), 1, mFileInt) == 1) {
        if (member.mId == mSearchId) {
            mFound = true;
            break;
        }
    }
    fclose(mFileInt);

    if (!mFound) {
        printf("Member dengan ID %d tidak ditemukan!\n", mSearchId);
        return;
    }

    printf("Nama: %s\n", member.mNama);
    printf("Tanggal Join: %s\n", member.mtgglJoin);
    printf("Tanggal Kadaluarsa: %s\n", member.mKadaluarsa);

    printf("Masukkan Tahun pembayaran: ");
    scanf("%d", &mTahun);
    printf("Masukkan Bulan pembayaran: ");
    scanf("%d", &mBulan);
    printf("Masukkan Tanggal pembayaran: ");
    scanf("%d", &mHari);

    snprintf(mTanggal, sizeof(mTanggal), "%04d-%02d-%02d", mTahun, mBulan, mHari);

    printf("\Total yang harus dibayar: %d\n", mTotal);
    printf("Masukkan jumlah uang yang diterima: ");
    scanf("%d", &mUangDiterima);

    if (mUangDiterima < mTotal) {
        printf("Uang yang diterima tidak cukup!\n");
        return;
    }

    mUangKembalian =  mUangDiterima - mTotal;
    printf("Uang kembalian: %d\n", mUangKembalian);

    MsimpanTransaksi(member, mTahun, mTotal, mTanggal);

    printf("Transaksi berhasil!\n");
}

void MbacaMemberTransaksi() {
    FILE *mFileTransaksi;
    dataTransaksi tdata;
    int mBulan;
    bool mIsEmpty = true;

    mFileTransaksi = fopen("LaporanTransaksi.dat", "rb");
    if (mFileTransaksi == NULL) {
        printf("File tidak dapat dibuka!\n");
        return;
    }

    while (fread(&tdata, sizeof(tdata), 1, mFileTransaksi) == 1) {
        if (mIsEmpty) {
            printf("||============||============||======================||================||============||============||\n");
            printf("|| %-10s || %-10s || %-20s || %-14s || %-10s || %-10s || \n", "ID Trans", "ID Member", "Nama", "mBulan Transaksi", "Tahun", "mTotal");
            printf("||============||============||======================||================||============||============||\n");
            mIsEmpty = false;
        }
        sscanf(tdata.mTanggal + 5, "%2d", &mBulan); // Extract the month from the date string
        printf("|| %-10d || %-10d || %-20s || %-14d || %-10d || %-10d || \n", tdata.mId, tdata.mId, tdata.mNama, mBulan, tdata.mTahun, tdata.mTotal);
    }

    if (mIsEmpty) {
        printf("Tidak ada transaksi yang ditemukan.\n");
    } else {
        printf("||============||============||======================||================||============||============||\n");
    }

    fclose(mFileTransaksi);
    getchar();
}

void MprosesTransaksi(datamember member, int mTotal, const char* mTanggal) {
    FILE *transaksiFile;
    FILE *mIdFile;
    dataTransaksi tdata;
    int mDataId = 0;

    transaksiFile = fopen("LaporanTransaksi.dat", "ab");
    mIdFile = fopen("LastTransID.dat", "r+b");
    if (transaksiFile == NULL || mIdFile == NULL) {
        printf("File tidak dapat dibuka!\n");
        return;
    }

    fread(&mDataId, sizeof(int), 1, mIdFile);
    mDataId = mDataId + 1;

    tdata.mId = mDataId;
    strcpy(tdata.mNama, member.mNama);
    tdata.mTotal = mTotal;
    strcpy(tdata.mTanggal, mTanggal);

    fwrite(&tdata, sizeof(tdata), 1, transaksiFile);

    fseek(mIdFile, 0, SEEK_SET);
    fwrite(&mDataId, sizeof(int), 1, mIdFile);

    fclose(transaksiFile);
    fclose(mIdFile);
}