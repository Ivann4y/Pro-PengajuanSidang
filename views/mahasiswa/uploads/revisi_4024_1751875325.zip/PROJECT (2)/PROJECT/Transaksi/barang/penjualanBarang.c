#include "../../Master/Barang/headd.h"

void simpanTransaksi(dataBarang bdata, int totalPenjualan) {
    FILE *fileTransaksi;
    dataTransaksi tdata;

    fileTransaksi = fopen("../../Master/Barang/LaporanTransaksi.dat", "ab");
    if (fileTransaksi == NULL) {
        printf("File tidak dapat dibuka!\n");
        return;
    }

    // Fill transaction details
    tdata.id = bdata.id;
    strcpy(tdata.nama, bdata.nama);
    strcpy(tdata.kategori, bdata.kategori);
    tdata.hargaJual = bdata.hargaJual;
    tdata.total = bdata.hargaJual;
    tdata.penjualan = totalPenjualan;

    // Capture current date as waktuJual
    time_t t = time(NULL);
    struct tm *currentTime = localtime(&t);
    strftime(tdata.waktuJual, sizeof(tdata.waktuJual), "%d-%m-%Y", currentTime);

    fwrite(&tdata, sizeof(tdata), 1, fileTransaksi);
    fclose(fileTransaksi);
}

int main() {
    FILE *fileBarang;
    dataBarang bdata;
    int id, found;
    int totalPenjualan = 0;
    char pilihan;

    do {
        found = 0;
        printf("Masukkan ID barang yang ingin dibeli (atau 9999 untuk berhenti): ");
        scanf("%d", &id);
        if (id == 9999) break;

        fileBarang = fopen("../../Master/Barang/DataBarang.dat", "rb");

        if (fileBarang == NULL) {
            printf("File tidak dapat dibuka!\n");
            return 1;
        }

        while (fread(&bdata, sizeof(bdata), 1, fileBarang) == 1) {
            if (bdata.id == id) {
                found = 1;
                totalPenjualan += bdata.hargaJual;

                // Save transaction
                simpanTransaksi(bdata, totalPenjualan);
                printf("Barang dengan ID %d berhasil dijual.\n", id);
                break;
            }
        }

        fclose(fileBarang);

        if (!found) {
            printf("Barang dengan ID %d tidak ditemukan!\n", id);
        }

        printf("Apakah Anda ingin menambah barang lagi? (y/n): ");
        scanf(" %c", &pilihan);
    } while (pilihan == 'y' || pilihan == 'Y');

    printf("Total harga penjualan: %d\n", totalPenjualan);
}
