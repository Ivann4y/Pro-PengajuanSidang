#include "../../Master/Barang/headd.h"

void SimpanTransaksi(dataBarang bdata, int jumlah, int totalSewa, const char* waktuSewa) {
    FILE *fileTransaksi;
    dataTransaksi tdata;

    fileTransaksi = fopen("../../Master/Barang/LaporanTransaksiSewa.dat", "ab");
    if (fileTransaksi == NULL) {
        printf("File tidak dapat dibuka!\n");
        return;
    }

    tdata.id = bdata.id;
    strcpy(tdata.nama, bdata.nama);
    strcpy(tdata.kategori, bdata.kategori);
    tdata.hargaSewa = bdata.hargaSewa;
    tdata.jumlah = jumlah;
    tdata.total = totalSewa;
    strcpy(tdata.waktuSewa, waktuSewa);

    fwrite(&tdata, sizeof(tdata), 1, fileTransaksi);
    fclose(fileTransaksi);
}

void UbahStatusBarang(int id) {
    FILE *fileBarang, *tempFile;
    dataBarang bdata;

    fileBarang = fopen("../../Master/Barang/DataBarang.dat", "rb");
    tempFile = fopen("../../Master/Barang/Temporary.dat", "wb");

    if (fileBarang == NULL || tempFile == NULL) {
        printf("File tidak dapat dibuka!\n");
        return;
    }

    while (fread(&bdata, sizeof(bdata), 1, fileBarang) == 1) {
        if (bdata.id == id) {
            strcpy(bdata.status, "Disewakan");
        }
        fwrite(&bdata, sizeof(bdata), 1, tempFile);
    }

    fclose(fileBarang);
    fclose(tempFile);

    remove("../../Master/Barang/DataBarang.dat");
    rename("../../Master/Barang/Temporary.dat", "../../Master/Barang/DataBarang.dat");
}

int main() {
    FILE *fileBarang;
    dataBarang bdata;
    int id, found;
    int totalsewa = 0;
    char pilihan;
    char waktuSewa[11];
    time_t t = time(NULL);
    struct tm *currentTime = localtime(&t);
    strftime(waktuSewa, sizeof(waktuSewa), "%d-%m-%Y", currentTime);

    do {
        found = 0;
        printf("Masukkan ID barang yang ingin disewa (atau 9999 untuk berhenti): ");
        scanf("%d", &id);
        if (id == 9999) break;

        fileBarang = fopen("../../Master/Barang/DataBarang.dat", "rb");

        if (fileBarang == NULL) {
            printf("File tidak dapat dibuka!\n");
            return 1;
        }

        while (fread(&bdata, sizeof(bdata), 1, fileBarang) == 1) {
            if (bdata.id == id) {
                found = 1;
                totalsewa += bdata.hargaSewa;
                SimpanTransaksi(bdata, 1, totalsewa, waktuSewa);
                UbahStatusBarang(id);
                break;
            }
        }

        fclose(fileBarang);

        if (!found) {
            printf("Barang dengan ID %d tidak ditemukan!\n", id);
        }

        printf("Apakah Anda ingin menambah barang lagi? (y/n): ");
        scanf(" %c", &pilihan);
    } while (pilihan == 'y' || pilihan == 'Y');

    printf("Total harga penyewaan: %d\n", totalsewa);
}
