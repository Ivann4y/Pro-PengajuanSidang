#include "../../Master/Barang/headd.h"

void pilihkategori(char *kategori) {
    int pilih = 0;
    char *kategoris[] = {"Kamera", "Lensa", "Tripod", "Lightning"};
    int menusize = sizeof(kategoris) / sizeof(kategoris[0]);
    char key;

    while (1) {
        printf("Pilih kategori untuk Barang baru: \n");

        for (int i = 0; i < 4; i++) {
            if (i == pilih) {
                printf(" ==> %s\n", kategoris[i]);
            } else {
                printf("    %s\n", kategoris[i]);
            }
        }

        key = getch();
        if (key == 13) {
            break;
        } else if (key == 72 && pilih > 0) {
            pilih--;
        } else if (key == 80 && pilih < menusize - 1) {
            pilih++;
        }

        system("cls");    
    }

    strcpy(kategori, kategoris[pilih]);
}
          
int main() {
    int found = 0;
    char nama[50];
    char kategori[15];
    dataBarang bData, tempData;
    FILE *baca;
    FILE *tulis;
    tulis = fopen("../../Master/Barang/DataBarang.dat", "ab");
    baca = fopen("../../Master/Barang/DataBarang.dat", "rb");

    int dataId = 0;
    char jawaban;
    int datastok = 0;

    printf("===INPUT DATA KARYAWAN===\n");

    while (fread(&bData, sizeof(bData), 1, baca) == 1) {
        if (bData.id >= dataId) {
            dataId = bData.id;
        }
        else if (bData.stok >= datastok){
            datastok = bData.stok;
        }
    }

    do{
        dataId = dataId+1;
        printf("ID Barang baru: B%d\n", dataId);
        bData.id = dataId;
        printf("Masukan nama Barang baru: "); scanf(" %[^\n]", &nama);
        pilihkategori(kategori);
         rewind(baca);
        found = 0;

        while (fread(&tempData, sizeof(tempData), 1, baca) == 1) {
            if (strcmp(tempData.nama, nama) == 0 && strcmp(tempData.kategori, kategori) == 0) {
                // Barang ditemukan
                found = 1;
                tempData.stok += 1; // Tambah stok
                printf("Barang sudah ada! Stok ditambah menjadi %d\n", tempData.stok);

                // Update stok barang di file
                fclose(baca);
                FILE *update = fopen("DataBarang.dat", "rb+");
                while (fread(&bData, sizeof(bData), 1, update) == 1) {
                    if (bData.id == tempData.id) {
                        fseek(update, -sizeof(bData), SEEK_CUR);
                        fwrite(&tempData, sizeof(tempData), 1, update);
                        break;
                    }
                }
                fclose(update);
                break;
            }
        }

        if (!found) {
            // Jika barang tidak ditemukan, tambahkan data baru
            strcpy(bData.nama, nama);
            strcpy(bData.kategori, kategori);
            printf("Masukkan harga sewa: "); 
            scanf("%d", &bData.hargaSewa);
            printf("Masukkan harga jual: "); 
            scanf("%d", &bData.hargaJual);
            printf("Stok Barang baru: ");
            scanf("%d", &bData.stok);
            
            fwrite(&bData, sizeof(bData), 1, tulis);
            printf("Barang baru telah ditambahkan!\n");
        }
        printf("Tambah Barang Lagi? (y/n): "); scanf(" %c", &jawaban);

        while (jawaban != 'y' && jawaban != 'Y' && jawaban != 'n' && jawaban != 'N') {
            printf("Input tidak valid! Masukkan input yang valid! (y/n): ");
            scanf(" %c", &jawaban);
        }

        system("cls");
    } while(jawaban == 'y' || jawaban == 'Y');

    getch();
  
    fclose(baca);
    fclose(tulis);
    return 0;

}