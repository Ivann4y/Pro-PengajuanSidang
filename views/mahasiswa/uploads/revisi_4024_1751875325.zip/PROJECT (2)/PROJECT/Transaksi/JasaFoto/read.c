#include "../../heading.h"

void printTransaksi() {
    FILE *readFile;
    tFotografi fotoData;
    readFile = fopen("TransaksiJasa.dat", "rb");
    printf("|| %-5s || %-20s || %-15s || %-15s || %-7s || %-15s ||", "No.", "Nama Customer", "Nomor Telepon", "Tanggal", "Paket Foto", "Durasi", "Total Harga");
    while (fread(&fotoData, sizeof(fotoData), 1, readFile) == 1) {
        printf("|| %-5d || %-20s || %-15d || %-2d/%d/%d || %-15s || %-3d jam || %-15d ||", fotoData.id, fotoData.nama, fotoData.noTelp, fotoData.tgl.tgl, fotoData.tgl.bln, fotoData.tgl.thn, fotoData.paket, fotoData.durasi, fotoData.tHarga);
    }
    fclose(readFile);
}

void printFotografer() {
    FILE *Fotografer;
    dataKaryawan kData;
    Fotografer = fopen("Fotografer.dat", "rb"); 
    while (fread(&kData, sizeof(kData), 1, Fotografer) == 1) {
        printf("%s || %s", kData.nama, kData.status);
    }
    fclose(Fotografer);
}

int main() {
    int selected;

    printf("Menu: \n");
    printf("[1] Laporan Transaksi\n");
    printf("[2] List Fotografer\n");
    printf("[3] Fotografer Bertugas\n");

    printf("Pilih menu: "); scanf("%d", &selected);

    switch (selected)
    {
    case 1:
        printTransaksi();
        break;
    case 2:
        printFotografer();
        break;
    default:
        break;
    }
    return 0;
}