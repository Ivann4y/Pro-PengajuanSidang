#include "../../heading.h"

void showList(FILE *Jasa) {
    Jasa = fopen("../../Master/JasaFoto/DataJasa.dat", "rb");
    printf("##### PENYEWAAN JASA FOTOGRAFI #####");
    printf("List Jasa Fotografi: ");
    listJasa jData;
    fread(&jData, sizeof(jData), 1, Jasa);
    printf("|| %-5s || %-20s || %-7s || %-15s ||", "No.", "Nama Paket", "Durasi", "Harga");
    while (fread(&jData, sizeof(jData), 1, Jasa) == 1) {
        printf("|| %-5d || %-20s || %-3d jam || %-15d ||", jData.id, jData.nama, jData.durasi, jData.harga);
    }
    fclose(Jasa);
}

void inputData(FILE *TJasa, FILE *Jasa, char namaCustomer[50]) {
    TJasa = fopen("TransaksiJasa.dat", "ab");
    Jasa = fopen("../../Master/JasaFoto/DataJasa.dat", "rb");
    listJasa jData;
    tFotografi fotoData;

    int dataId = 0;

    while (fread(&fotoData, sizeof(fotoData), 1, TJasa) == 1) {
        if (fotoData.id >= dataId) {
            dataId = fotoData.id;
        }
    }

    fotoData.id = dataId + 1;

    int searchId;
    int durasi;

    printf("Input Data: ");
    printf("Nama Customer: "); scanf(" %[^\n]", &*namaCustomer);
    strcpy(fotoData.nama, namaCustomer);
    printf("Nomor Telepon: "); scanf("%d", &fotoData.noTelp);
    printf("Tanggal Pemotretan: "); scanf("%d/%d/%d", &fotoData.tgl.tgl, &fotoData.tgl.bln, &fotoData.tgl.thn);
    printf("Paket Foto: "); scanf("%d", &searchId);

    while (fread(&jData, sizeof(jData), 1, Jasa) == 1) {
        if (jData.id == searchId) {
            strcpy(fotoData.paket, jData.nama);
            break;
        }
    }

    printf("Durasi: "); scanf("%d", &durasi);
    fotoData.durasi = jData.durasi * durasi;
    fotoData.tHarga = jData.harga * durasi;
    fwrite(&fotoData, sizeof(fotoData), 1, TJasa);
    fclose(TJasa);
    fclose(Jasa);
}


void printData(char namaCustomer[50]) {
    FILE *TJasa;
    TJasa = fopen("TransaksiJasa.dat", "rb");
    tFotografi fotoData;
    printf("|| %-5s || %-20s || %-15s || %-15s || %-7s || %-15s ||", "No.", "Nama Customer", "Nomor Telepon", "Tanggal", "Paket Foto", "Durasi", "Total Harga");
    while (fread(&fotoData, sizeof(fotoData), 1, TJasa) == 1) {
        if (strcmp(fotoData.nama, namaCustomer) == 0) {
            printf("|| %-5d || %-20s || %-15d || %d/%d/%d  || %-20s || %-3d jam || %-15d ||", fotoData.id, fotoData.nama, fotoData.noTelp, fotoData.tgl.tgl, fotoData.tgl.bln, fotoData.tgl.thn, fotoData.paket, fotoData.durasi, fotoData.tHarga);
        }
    }
    fclose(TJasa);
}

int main() {
    FILE *Jasa;
    FILE *TJasa;
    char namaCustomer[50];
    showList(Jasa);
    inputData(TJasa, Jasa, namaCustomer);
    printData(namaCustomer);
    return 0;
}