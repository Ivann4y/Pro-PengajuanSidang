#include <stdio.h>
#include <string.h>
#include <conio.h>
#include <stdlib.h>
#include <time.h>
#include <windows.h>
#include <stdbool.h>

typedef struct
{
    int tgl;
    int bln;
    int thn;
} tanggal;

typedef struct 
{
    int id;
    char nama[50];
    char pasword[20];
    char role[15];
    int notelp;
    char status[15];
} dataKaryawan; 

typedef struct 
{
    int id;
    char nama[50];
    int durasi;
    int harga;
} listJasa; 

typedef struct {
    int id;
    char nama[50];
    char notelp[15];
    char tgglJoin[11];
    char kadaluarsa[11];
} datamember;

typedef struct {
    int id;
    char nama[50];
    int tahun;
    int total;
    char tanggal[11];
} dataTransaksi;

typedef struct 
{
    int id;
    char nama[50];
    char kategori[15];
    int hargaSewa;
    int hargaJual;
    int stok;
    char status[20];

} dataBarang; 

typedef struct {
    int id;
    tanggal tgl;
    char paket[20];
    char nama[50];
    int noTelp;
    int durasi;
    int tHarga;
} tFotografi;

typedef struct {
    int id;
    char nama[50];
    char kategori[15];
    int hargaJual;
    int hargaSewa;
    int jumlah;
    int total;
    char waktuJual[11];
    char waktuSewa[11];
    int penjualan;
    int penyewaan;

    } dataTransaksiBarang;