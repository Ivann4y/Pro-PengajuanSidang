import numpy as np

# Definisikan matriks A
A = np.array([[3, 1, 1],
              [1, 3, 1],
              [1, 1, 3]])

# Hitung nilai eigen dan vektor eigen
eigenvalues, eigenvectors = np.linalg.eigh(A)

# eigenvectors sudah ortonormal karena A simetris
P = eigenvectors

# Hitung P^T * A * P
P_T = P.T
D = P_T @ A @ P

# Fungsi bantu untuk membulatkan dan menampilkan matriks
def print_matrix(name, matrix):
    print(f"\n{name}:")
    rounded = np.round(matrix, 3)
    print(rounded)

# Cetak hasil
print("\nNilai eigen:")
print(np.round(eigenvalues, 3))

print_matrix("Matriks P (vektor-vektor eigen sebagai kolom)", P)
print_matrix("P^T * A * P (hasil diagonal)", D)
