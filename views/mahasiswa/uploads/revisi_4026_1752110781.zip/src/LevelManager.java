import java.util.*;

public class LevelManager {
    private Graph levelGraph;

    public LevelManager() {
        levelGraph = new Graph();
    }

    public void loadLevels() {
        // Example hardcoded levels
        levelGraph.addNode(0); // root
        levelGraph.addNode(1);
        levelGraph.addNode(2);
        levelGraph.addNode(3);
        levelGraph.addEdge(0, 1);
        levelGraph.addEdge(1, 2);
        levelGraph.addEdge(1, 3);
    }

    public void printLevels() {
        levelGraph.printGraph();
    }
}
