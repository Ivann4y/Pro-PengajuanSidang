public class Game {
    private LevelManager levelManager;
    private int currentLevel = 0;

    public Game() {
        levelManager = new LevelManager();
    }

    public void start() {
        System.out.println("Starting game...");
        levelManager.loadLevels();
        levelManager.printLevels();
        // Future: Launch game window, draw platforms, handle gameplay
    }
}
